from pptx import Presentation
from pptx.util import Inches
import datetime

prs = Presentation()

# Slide 1 - Titre
slide = prs.slides.add_slide(prs.slide_layouts[0])
title = slide.shapes.title
subtitle = slide.placeholders[1]
title.text = "Africa Golden Digital"
subtitle.text = "Rapport d'activité - Mars 2026"

# Slide 2 - Services
slide = prs.slides.add_slide(prs.slide_layouts[1])
title = slide.shapes.title
content = slide.placeholders[1]
title.text = "Nos Services"
content.text = "• Accompagnement Digital\n• Automatisation IA\n• Création de contenu\n• Formation"

# Slide 3 - Chiffres
slide = prs.slides.add_slide(prs.slide_layouts[1])
title = slide.shapes.title
content = slide.placeholders[1]
title.text = "Résultats"
content.text = "• Nouveaux clients : 12\n• Devis envoyés : 25\n• Ventes réalisées : 8\n• Chiffre d'affaires : 2.5M FCFA"

# Slide 4 - Contact
slide = prs.slides.add_slide(prs.slide_layouts[1])
title = slide.shapes.title
content = slide.placeholders[1]
title.text = "Contact"
content.text = "Kora - Assistante IA\nWhatsApp: +2290149308718\nEmail: contact@africagoldendigital.com"

filename = f"C:\\Users\\DELL\\Desktop\\presentation_{datetime.datetime.now().strftime('%Y%m%d')}.pptx"
prs.save(filename)
print(f"PowerPoint créé : {filename}")