#!/usr/bin/env python3
"""
Email professionnel avec design, couleurs et images
Créé pour KORA - Africa Golden Digital
Par défaut en français, peut être en anglais sur demande
"""

import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import sys
import os
import datetime
from PIL import Image, ImageDraw, ImageFont
import random

# Langue par défaut
DEFAULT_LANG = "fr"

def random_color():
    colors = [
        "#2E86C1", "#3498DB", "#5DADE2", "#85C1E9", "#D4E6F1",
        "#27AE60", "#2ECC71", "#58D68D", "#82E0AA", "#D5F5E3",
        "#E67E22", "#F39C12", "#F5B041", "#FAD7A0", "#FEF5E7",
        "#E74C3C", "#F1948A", "#F5B7B1", "#FDEDEC",
        "#9B59B6", "#8E44AD", "#AF7AC5", "#D2B4DE",
        "#F1C40F", "#F4D03F", "#F7DC6F", "#F9E79F",
        "#1ABC9C", "#16A085", "#48C9B0", "#76D7C4"
    ]
    return random.choice(colors)

def generate_image(company_name, client_name, amount, status, lang="fr"):
    """Génère une image personnalisée pour l'email"""
    bg_color = random_color()
    img = Image.new('RGB', (600, 200), color=bg_color)
    draw = ImageDraw.Draw(img)
    
    try:
        font_title = ImageFont.truetype("arial.ttf", 24)
        font_text = ImageFont.truetype("arial.ttf", 16)
    except:
        font_title = ImageFont.load_default()
        font_text = ImageFont.load_default()
    
    # Texte selon la langue
    if lang == "fr":
        client_label = "Client"
        amount_label = "Montant"
        status_label = "Statut"
    else:
        client_label = "Client"
        amount_label = "Amount"
        status_label = "Status"
    
    draw.text((50, 50), f"📊 {company_name}", fill='white', font=font_title)
    draw.text((50, 100), f"{client_label} : {client_name}", fill='white', font=font_text)
    draw.text((50, 140), f"{amount_label} : {amount} FCFA", fill='white', font=font_text)
    draw.text((50, 170), f"{status_label} : {status}", fill='white', font=font_text)
    
    filename = f"C:\\Users\\DELL\\Desktop\\kora_email_img_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
    img.save(filename)
    return filename

def generate_html_email(client_name, subject, amount, status, services, image_path=None, lang="fr"):
    """Génère un email HTML avec design pro - français par défaut"""
    
    bg_color = random_color()
    
    status_color = '#d4edda' if status == 'Payé' or status == 'Paid' else '#fff3cd'
    status_text_color = '#155724' if status == 'Payé' or status == 'Paid' else '#856404'
    
    # Contenu selon la langue
    if lang == "fr":
        # VERSION FRANÇAISE
        html = f"""
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Language" content="fr">
    <title>{subject} - KORA</title>
    <style>
        body {{ margin: 0; padding: 0; font-family: 'Segoe UI', Arial, sans-serif; background-color: #f4f4f4; }}
        .container {{ max-width: 600px; margin: 20px auto; background-color: #ffffff; border-radius: 15px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }}
        .header {{ background: linear-gradient(135deg, {bg_color}, {bg_color}dd); padding: 30px; text-align: center; color: white; }}
        .header h1 {{ margin: 0; font-size: 28px; }}
        .header p {{ margin: 10px 0 0; opacity: 0.9; }}
        .content {{ padding: 30px; }}
        .greeting {{ font-size: 18px; color: #333; margin-bottom: 20px; }}
        .info-card {{ background-color: #f8f9fa; border-radius: 10px; padding: 20px; margin: 20px 0; border-left: 4px solid {bg_color}; }}
        .info-card h3 {{ margin: 0 0 10px; color: {bg_color}; }}
        .info-card p {{ margin: 5px 0; color: #555; }}
        .amount {{ font-size: 32px; font-weight: bold; color: {bg_color}; text-align: center; margin: 20px 0; }}
        .services {{ background-color: #e8f4fd; border-radius: 10px; padding: 15px; margin: 20px 0; }}
        .services ul {{ margin: 0; padding-left: 20px; }}
        .services li {{ margin: 8px 0; color: #555; }}
        .footer {{ background-color: #f8f9fa; padding: 20px; text-align: center; color: #666; font-size: 12px; border-top: 1px solid #eee; }}
        .button {{ display: inline-block; background-color: {bg_color}; color: white; padding: 12px 30px; text-decoration: none; border-radius: 25px; margin: 20px 0; font-weight: bold; }}
        .status {{ display: inline-block; padding: 5px 15px; border-radius: 20px; font-size: 12px; font-weight: bold; background-color: {status_color}; color: {status_text_color}; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header"><h1>🌊 Africa Golden Digital</h1><p>Votre assistant intelligent KORA</p></div>
        <div class="content">
            <div class="greeting">Bonjour <strong>{client_name}</strong> 👋,</div>
            <p>Nous vous remercions pour votre confiance. Voici les détails de votre demande :</p>
            <div class="info-card"><h3>📋 Détails</h3><p><strong>Sujet :</strong> {subject}</p><p><strong>Date :</strong> {datetime.datetime.now().strftime('%d/%m/%Y')}</p><p><strong>Statut :</strong> <span class="status">{status}</span></p></div>
            <div class="amount">{amount} FCFA</div>
            <div class="services"><h3>💼 Services inclus</h3><ul>{''.join([f'<li>✅ {s}</li>' for s in services])}</ul></div>
            <div style="text-align: center;"><a href="#" class="button">📄 Voir les détails</a></div>
            <p style="margin-top: 20px;">Pour toute question, n'hésitez pas à me contacter directement.</p>
            <p>Cordialement,<br><strong>KORA 🌊</strong><br>Assistante IA - Africa Golden Digital</p>
        </div>
        <div class="footer">
            <p>📱 WhatsApp : +2290149308718 | 📧 contact@africagoldendigital.com</p>
            <p>© 2026 Africa Golden Digital - Tous droits réservés</p>
            <p>Cet email a été généré automatiquement par KORA.</p>
        </div>
    </div>
</body>
</html>
        """
    else:
        # VERSION ANGLAISE
        html = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="Content-Language" content="en">
    <title>{subject} - KORA</title>
    <style>
        body {{ margin: 0; padding: 0; font-family: 'Segoe UI', Arial, sans-serif; background-color: #f4f4f4; }}
        .container {{ max-width: 600px; margin: 20px auto; background-color: #ffffff; border-radius: 15px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }}
        .header {{ background: linear-gradient(135deg, {bg_color}, {bg_color}dd); padding: 30px; text-align: center; color: white; }}
        .header h1 {{ margin: 0; font-size: 28px; }}
        .header p {{ margin: 10px 0 0; opacity: 0.9; }}
        .content {{ padding: 30px; }}
        .greeting {{ font-size: 18px; color: #333; margin-bottom: 20px; }}
        .info-card {{ background-color: #f8f9fa; border-radius: 10px; padding: 20px; margin: 20px 0; border-left: 4px solid {bg_color}; }}
        .info-card h3 {{ margin: 0 0 10px; color: {bg_color}; }}
        .info-card p {{ margin: 5px 0; color: #555; }}
        .amount {{ font-size: 32px; font-weight: bold; color: {bg_color}; text-align: center; margin: 20px 0; }}
        .services {{ background-color: #e8f4fd; border-radius: 10px; padding: 15px; margin: 20px 0; }}
        .services ul {{ margin: 0; padding-left: 20px; }}
        .services li {{ margin: 8px 0; color: #555; }}
        .footer {{ background-color: #f8f9fa; padding: 20px; text-align: center; color: #666; font-size: 12px; border-top: 1px solid #eee; }}
        .button {{ display: inline-block; background-color: {bg_color}; color: white; padding: 12px 30px; text-decoration: none; border-radius: 25px; margin: 20px 0; font-weight: bold; }}
        .status {{ display: inline-block; padding: 5px 15px; border-radius: 20px; font-size: 12px; font-weight: bold; background-color: {status_color}; color: {status_text_color}; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header"><h1>🌊 Africa Golden Digital</h1><p>Your intelligent assistant KORA</p></div>
        <div class="content">
            <div class="greeting">Hello <strong>{client_name}</strong> 👋,</div>
            <p>Thank you for your trust. Here are the details of your request:</p>
            <div class="info-card"><h3>📋 Details</h3><p><strong>Subject:</strong> {subject}</p><p><strong>Date:</strong> {datetime.datetime.now().strftime('%d/%m/%Y')}</p><p><strong>Status:</strong> <span class="status">{status}</span></p></div>
            <div class="amount">{amount} FCFA</div>
            <div class="services"><h3>💼 Services included</h3><ul>{''.join([f'<li>✅ {s}</li>' for s in services])}</ul></div>
            <div style="text-align: center;"><a href="#" class="button">📄 View details</a></div>
            <p style="margin-top: 20px;">If you have any questions, please contact me directly.</p>
            <p>Best regards,<br><strong>KORA 🌊</strong><br>AI Assistant - Africa Golden Digital</p>
        </div>
        <div class="footer">
            <p>📱 WhatsApp : +2290149308718 | 📧 contact@africagoldendigital.com</p>
            <p>© 2026 Africa Golden Digital - All rights reserved</p>
            <p>This email was automatically generated by KORA.</p>
        </div>
    </div>
</body>
</html>
        """
    
    if image_path and os.path.exists(image_path):
        html = html.replace('<div class="amount">', f'<div style="text-align:center;"><img src="cid:kora_image" style="max-width:100%; border-radius:10px; margin:20px 0;"></div><div class="amount">')
    
    return html

def send_chic_email(to_address, client_name, subject, amount, status, services, lang="fr"):
    """Envoie un email chic avec image générée - français par défaut"""
    
    smtp_server = "smtp.gmail.com"
    smtp_port = 587
    sender_email = "gbodogbejores5@gmail.com"
    password = "sgcvjfdillfhfdyg"
    
    # Générer une image personnalisée
    image_path = generate_image("Africa Golden Digital", client_name, amount, status, lang)
    
    # Créer l'email
    message = MIMEMultipart("alternative")
    message["Subject"] = f"📧 {subject} - KORA"
    message["From"] = f"KORA 🌊 <{sender_email}>"
    message["To"] = to_address
    
    # Générer HTML
    html_content = generate_html_email(client_name, subject, amount, status, services, image_path, lang)
    message.attach(MIMEText(html_content, "html", "utf-8"))
    
    # Ajouter l'image comme pièce jointe inline
    with open(image_path, "rb") as img:
        img_part = MIMEBase("image", "png")
        img_part.set_payload(img.read())
        encoders.encode_base64(img_part)
        img_part.add_header("Content-ID", "<kora_image>")
        img_part.add_header("Content-Disposition", "inline", filename="kora_image.png")
        message.attach(img_part)
    
    # Envoi
    try:
        context = ssl.create_default_context()
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls(context=context)
            server.login(sender_email, password.replace(" ", ""))
            server.sendmail(sender_email, to_address, message.as_string())
        print(f"✅ Email envoyé à {to_address} ({'français' if lang == 'fr' else 'anglais'})")
        return True
    except Exception as e:
        print(f"❌ Erreur : {e}")
        return False

def main():
    # Détection de la langue
    lang = DEFAULT_LANG
    
    # Si le dernier argument est "en" ou "anglais", on passe en anglais
    if len(sys.argv) > 1 and sys.argv[-1].lower() in ["en", "anglais", "english"]:
        lang = "en"
        # Enlever le dernier argument
        args = sys.argv[1:-1]
    else:
        args = sys.argv[1:]
    
    if len(args) < 4:
        print("Utilisation: python send_email_chic.py <email> <client> <sujet> <montant> <status> [en]")
        print("Exemple (français): python send_email_chic.py client@gmail.com 'Jean Dupont' 'Devis' 150000 'Payé'")
        print("Exemple (anglais): python send_email_chic.py client@gmail.com 'Jean Dupont' 'Quote' 150000 'Paid' en")
        sys.exit(1)
    
    to_address = args[0]
    client_name = args[1]
    subject = args[2]
    amount = args[3]
    status = args[4] if len(args) > 4 else "En cours"
    
    services = [
        "Automatisation WhatsApp",
        "Tableaux de bord Excel",
        "Rapports hebdomadaires",
        "Support client 24/7"
    ]
    
    success = send_chic_email(to_address, client_name, subject, amount, status, services, lang)
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()