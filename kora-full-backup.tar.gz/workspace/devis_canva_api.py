#!/usr/bin/env python3
"""
Devis avec Canva API
Créé pour KORA - Africa Golden Digital
"""

import requests
import datetime
import json
import os

# À remplacer par ta vraie clé API
CANVA_API_KEY = "ta_cle_api_canva"

def create_devis_canva(client_name, services, total):
    """Crée un devis via Canva API"""
    
    # 1. Créer un design
    headers = {
        "Authorization": f"Bearer {CANVA_API_KEY}",
        "Content-Type": "application/json"
    }
    
    # Template de devis (à créer sur Canva d'abord)
    data = {
        "title": f"Devis {client_name} - {datetime.datetime.now().strftime('%d/%m/%Y')}",
        "template_id": "devis_template_001",  # À créer sur Canva
        "data": {
            "client_name": client_name,
            "date": datetime.datetime.now().strftime('%d/%m/%Y'),
            "services": "\n".join([f"- {s['name']} : {s['price']:,} FCFA" for s in services]),
            "total": f"{total:,} FCFA"
        }
    }
    
    response = requests.post(
        "https://api.canva.com/v1/designs",
        headers=headers,
        json=data
    )
    
    if response.status_code == 200:
        design_id = response.json()["id"]
        print(f"✅ Design créé : {design_id}")
        
        # Exporter en PDF
        export = requests.post(
            f"https://api.canva.com/v1/designs/{design_id}/export",
            headers=headers,
            json={"format": "pdf"}
        )
        
        if export.status_code == 200:
            pdf_url = export.json()["url"]
            print(f"✅ PDF : {pdf_url}")
            return pdf_url
    
    print(f"❌ Erreur : {response.text}")
    return None

if __name__ == "__main__":
    services = [
        {"name": "Création site web", "price": 250000},
        {"name": "Formation IA", "price": 100000}
    ]
    create_devis_canva("Jean Dupont", services, 350000)