# DEVIS

**Date :** 30 Mars 2026  
**N° Devis :** DEV-2026-001

---

## PRESTATAIRE
**Entreprise :** [Nom de votre entreprise]  
**Adresse :** [Votre adresse]  
**Email :** [Votre email]  
**Téléphone :** [Votre téléphone]

---

## CLIENT
**Nom :** Jean Dupont  
**Adresse :** [À compléter]  
**Email :** [À compléter]  
**Téléphone :** [À compléter]

---

## PRESTATIONS

| Description | Quantité | Prix Unitaire | Total |
|-------------|----------|---------------|-------|
| Création de site web | 1 | 250 000 FCFA | 250 000 FCFA |
| Formation IA | 1 | 100 000 FCFA | 100 000 FCFA |

---

## RÉCAPITULATIF

| | Montant |
|---|---|
| **Total HT** | 350 000 FCFA |
| **TVA (18%)** | 63 000 FCFA |
| **TOTAL TTC** | **413 000 FCFA** |

---

## CONDITIONS
- **Validité du devis :** 30 jours
- **Délai d'exécution :** À convenir
- **Modalités de paiement :** 50% à la commande, 50% à la livraison
- **Moyen de paiement :** Virement bancaire / Mobile Money

---

**Signature du prestataire**

Date : ___________

**Signature du client**

Date : ___________

---

*Ce devis est établi sans engagement et vaut acceptation sur signature.*
