#!/usr/bin/env python3
"""
Génère un devis en PDF avec Pandoc
Créé pour KORA - Africa Golden Digital
"""

import datetime
import random
import subprocess
import sys
import os

def create_devis_pandoc(client_name, services, tva=18):
    """Crée un devis PDF avec Pandoc"""
    
    devis_number = f"DEV-{datetime.datetime.now().strftime('%Y%m')}-{random.randint(1000, 9999)}"
    total_ht = sum(s['price'] for s in services)
    tva_amount = total_ht * tva / 100
    total_ttc = total_ht + tva_amount
    
    # Générer les lignes du tableau
    services_rows = ""
    for s in services:
        services_rows += f"| {s['name']} | 1 | {s['price']:,} | {s['price']:,} |\n"
    
    # Créer le contenu Markdown
    content = f"""---
title: "Devis {client_name}"
author: "Africa Golden Digital"
date: {datetime.datetime.now().strftime('%d/%m/%Y')}
geometry: margin=2.5cm
fontsize: 12pt
---

# 🌊 AFRICA GOLDEN DIGITAL

## DEVIS PROFESSIONNEL

---

### INFORMATIONS

| | |
|---|---|
| **Devis N°** | {devis_number} |
| **Date** | {datetime.datetime.now().strftime('%d/%m/%Y')} |
| **Client** | {client_name} |
| **Validité** | 30 jours |

---

### DÉTAIL DES PRESTATIONS

| Service | Qté | Prix unitaire (FCFA) | Montant (FCFA) |
|---------|-----|---------------------|----------------|
{services_rows}

---

### RÉCAPITULATIF

| | Montant (FCFA) |
|---|---|
| **Total HT** | {total_ht:,} |
| **TVA ({tva}%)** | {tva_amount:,.0f} |
| **TOTAL TTC** | **{total_ttc:,.0f}** |

---

### CONDITIONS

- Devis valable 30 jours
- Paiement à réception
- Commencez dès validation

---

**KORA 🌊** - WhatsApp: +2290149308718
"""
    
    # Sauvegarder le MD
    md_filename = f"C:\\Users\\DELL\\Desktop\\devis_{client_name.replace(' ', '_')}_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.md"
    with open(md_filename, 'w', encoding='utf-8') as f:
        f.write(content)
    
    # Convertir en PDF avec Pandoc
    pdf_filename = md_filename.replace('.md', '.pdf')
    
    try:
        result = subprocess.run([
            'pandoc', md_filename,
            '-o', pdf_filename,
            '--pdf-engine=pdflatex',
            '-V', 'geometry:margin=2.5cm',
            '-V', 'fontsize=12pt'
        ], capture_output=True, text=True)
        
        if result.returncode == 0:
            print(f"\n✅ DEVIS CRÉÉ AVEC SUCCÈS !")
            print(f"="*50)
            print(f"   📄 PDF : {pdf_filename}")
            print(f"   📊 Total HT : {total_ht:,} FCFA")
            print(f"   📊 Total TTC : {total_ttc:,.0f} FCFA")
            print(f"   🏷️  Devis N° : {devis_number}")
            print(f"   👤 Client : {client_name}")
            print(f"="*50)
            return pdf_filename
        else:
            print(f"\n⚠️ Conversion PDF impossible, mais fichier MD créé !")
            print(f"📁 Fichier MD : {md_filename}")
            print(f"👉 Ouvre-le avec Word ou Google Docs et exporte en PDF")
            print(f"❌ Erreur Pandoc : {result.stderr}")
            return None
            
    except Exception as e:
        print(f"❌ Erreur : {e}")
        print(f"📁 Fichier MD sauvegardé : {md_filename}")
        return None

def main():
    if len(sys.argv) < 4:
        print("\n" + "="*60)
        print("🏢 GÉNÉRATEUR DE DEVIS (Pandoc)")
        print("="*60)
        print("\nUtilisation:")
        print("  python devis_pandoc.py <client> <service1> <prix1> [service2] [prix2] ...")
        print("\nExemple:")
        print("  python devis_pandoc.py 'Jean Dupont' 'Création site' 250000 'Formation' 100000")
        print("\nLe PDF sera créé sur votre Bureau.")
        print("="*60)
        sys.exit(1)
    
    client = sys.argv[1]
    services = []
    
    i = 2
    while i < len(sys.argv):
        if i+1 < len(sys.argv):
            try:
                price = int(sys.argv[i+1])
                services.append({"name": sys.argv[i], "price": price})
                i += 2
            except ValueError:
                i += 1
        else:
            i += 1
    
    if not services:
        print("❌ Aucun service valide trouvé")
        sys.exit(1)
    
    print("\n" + "="*60)
    print("🏢 AFRICA GOLDEN DIGITAL - GÉNÉRATION DE DEVIS")
    print("="*60)
    print(f"👤 Client : {client}")
    print(f"📦 Services :")
    for s in services:
        print(f"   - {s['name']} : {s['price']:,} FCFA")
    print("="*60)
    
    create_devis_pandoc(client, services)

if __name__ == "__main__":
    main()