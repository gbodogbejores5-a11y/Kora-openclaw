#!/usr/bin/env python3
"""
Générateur de devis PDF direct (sans template externe)
Créé pour KORA - Africa Golden Digital
"""

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib.enums import TA_CENTER, TA_RIGHT, TA_LEFT
import datetime
import random
import os

# Configuration
CONFIG = {
    "entreprise": "AFRICA GOLDEN DIGITAL",
    "slogan": "L'excellence digitale",
    "whatsapp": "+2290149308718",
    "email": "contact@africagoldendigital.com",
    "couleur_principale": "#1E3A5F",
    "couleur_accent": "#C9A87C"
}

def format_number(n):
    return f"{n:,.0f}".replace(",", " ")

def create_devis(client_name, services, tva=18):
    """Crée un devis PDF professionnel"""
    
    total_ht = sum(s['price'] for s in services)
    tva_amount = total_ht * tva / 100
    total_ttc = total_ht + tva_amount
    devis_number = f"DEV-{datetime.datetime.now().strftime('%Y%m')}-{random.randint(100, 999)}"
    
    filename = f"C:\\Users\\DELL\\Desktop\\DEVIS_{client_name.replace(' ', '_')}_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.pdf"
    
    doc = SimpleDocTemplate(filename, pagesize=A4, topMargin=2*cm, bottomMargin=2*cm)
    story = []
    styles = getSampleStyleSheet()
    
    # Styles
    title_style = ParagraphStyle('Title', parent=styles['Normal'],
                                   fontSize=24, textColor=colors.HexColor(CONFIG["couleur_principale"]),
                                   alignment=TA_CENTER, spaceAfter=5, fontName='Helvetica-Bold')
    sub_style = ParagraphStyle('Sub', parent=styles['Normal'],
                                 fontSize=10, textColor=colors.grey, alignment=TA_CENTER)
    section_style = ParagraphStyle('Section', parent=styles['Normal'],
                                     fontSize=14, textColor=colors.HexColor(CONFIG["couleur_principale"]),
                                     spaceAfter=10, spaceBefore=20, fontName='Helvetica-Bold')
    
    # En-tête
    story.append(Paragraph(f"🌊 {CONFIG['entreprise']}", title_style))
    story.append(Paragraph(CONFIG['slogan'], sub_style))
    story.append(Spacer(1, 20))
    
    # Informations devis
    info_data = [
        ["DEVIS N°", devis_number],
        ["DATE", datetime.datetime.now().strftime('%d/%m/%Y')],
        ["CLIENT", client_name],
        ["VALIDITÉ", "30 jours"]
    ]
    
    info_table = Table(info_data, colWidths=[4*cm, 8*cm])
    info_table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('ALIGN', (0, 0), (0, -1), 'RIGHT'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BACKGROUND', (1, 0), (1, -1), colors.HexColor("#F5F7FA")),
    ]))
    story.append(info_table)
    story.append(Spacer(1, 20))
    
    # Section services
    story.append(Paragraph("📋 DÉTAIL DES PRESTATIONS", section_style))
    
    # Tableau
    table_data = [['SERVICE', 'QTÉ', 'PRIX UNITAIRE', 'MONTANT']]
    for s in services:
        table_data.append([
            s['name'],
            '1',
            f"{format_number(s['price'])} FCFA",
            f"{format_number(s['price'])} FCFA"
        ])
    
    service_table = Table(table_data, colWidths=[8*cm, 2*cm, 3.5*cm, 3.5*cm])
    service_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor(CONFIG["couleur_principale"])),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('FONTSIZE', (0, 1), (-1, -1), 9),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#CCCCCC")),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
    ]))
    story.append(service_table)
    story.append(Spacer(1, 15))
    
    # Totaux
    total_data = [
        ["TOTAL HT", f"{format_number(total_ht)} FCFA"],
        [f"TVA ({tva}%)", f"{format_number(tva_amount)} FCFA"],
        ["TOTAL TTC", f"{format_number(total_ttc)} FCFA"]
    ]
    
    total_table = Table(total_data, colWidths=[10*cm, 6*cm])
    total_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (0, -1), 'RIGHT'),
        ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
        ('FONTNAME', (0, -1), (1, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, -1), (1, -1), 12),
        ('TEXTCOLOR', (0, -1), (1, -1), colors.HexColor(CONFIG["couleur_accent"])),
        ('TOPPADDING', (0, 0), (-1, -1), 5),
    ]))
    story.append(total_table)
    story.append(Spacer(1, 30))
    
    # Conditions
    story.append(Paragraph("📌 CONDITIONS", section_style))
    conditions = [
        "• Devis valable 30 jours",
        "• Paiement à réception",
        "• Commencez dès validation"
    ]
    for cond in conditions:
        story.append(Paragraph(cond, styles['Normal']))
    
    story.append(Spacer(1, 30))
    
    # Pied de page
    story.append(Paragraph(f"📱 WhatsApp: {CONFIG['whatsapp']} | 📧 {CONFIG['email']}", 
                          ParagraphStyle('Footer', parent=styles['Normal'], fontSize=8, 
                                        textColor=colors.grey, alignment=TA_CENTER)))
    story.append(Paragraph(f"🌊 {CONFIG['signature'] if 'signature' in CONFIG else 'KORA - Assistante IA'}", 
                          ParagraphStyle('Footer2', parent=styles['Normal'], fontSize=9, 
                                        textColor=colors.HexColor(CONFIG["couleur_accent"]), alignment=TA_CENTER)))
    
    doc.build(story)
    print(f"\n✅ DEVIS PDF CRÉÉ !")
    print(f"="*50)
    print(f"📄 {filename}")
    print(f"💰 Total : {format_number(total_ttc)} FCFA")
    print(f"🏷️  N° : {devis_number}")
    print(f"="*50)
    return filename

def main():
    print("\n" + "="*60)
    print(f"✨ {CONFIG['entreprise']} - GÉNÉRATEUR DE DEVIS")
    print("="*60)
    
    client = input("👤 Nom du client : ")
    
    services = []
    i = 1
    while True:
        name = input(f"📦 Service {i} (ou 'fin' pour terminer) : ")
        if name.lower() == 'fin':
            break
        try:
            price = int(input(f"💰 Prix (FCFA) : "))
            services.append({"name": name, "price": price})
            i += 1
        except ValueError:
            print("❌ Entrez un nombre")
    
    if services:
        create_devis(client, services)

if __name__ == "__main__":
    main()