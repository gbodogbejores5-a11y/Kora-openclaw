#!/usr/bin/env python3
"""
Convertit un fichier Markdown en PDF
Créé pour KORA
"""

import subprocess
import sys
import os

def convert_to_pdf(md_file, output_pdf=None):
    """Convertit un fichier Markdown en PDF"""
    
    if not os.path.exists(md_file):
        print(f"❌ Fichier introuvable : {md_file}")
        return None
    
    if not output_pdf:
        output_pdf = md_file.replace('.md', '.pdf')
    
    try:
        result = subprocess.run([
            'pandoc', md_file,
            '-o', output_pdf,
            '--pdf-engine=pdflatex',
            '-V', 'geometry:margin=2.5cm',
            '-V', 'fontsize=12pt'
        ], capture_output=True, text=True)
        
        if result.returncode == 0:
            print(f"✅ PDF créé : {output_pdf}")
            return output_pdf
        else:
            print(f"❌ Erreur : {result.stderr}")
            return None
            
    except Exception as e:
        print(f"❌ Erreur : {e}")
        return None

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Utilisation: python generate_pdf.py <fichier.md>")
        sys.exit(1)
    
    convert_to_pdf(sys.argv[1])