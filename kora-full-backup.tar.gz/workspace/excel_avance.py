import openpyxl
import datetime
from openpyxl.styles import Font, PatternFill, Alignment

wb = openpyxl.Workbook()
ws = wb.active
ws.title = "Clients"

# Style titres
title_font = Font(bold=True, color="FFFFFF")
title_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")

# En-têtes
headers = ["Nom", "Prénom", "Email", "Téléphone", "Date", "Statut"]
for col, header in enumerate(headers, 1):
    cell = ws.cell(row=1, column=col, value=header)
    cell.font = title_font
    cell.fill = title_fill
    cell.alignment = Alignment(horizontal="center")

# Données clients
clients = [
    ["Dupont", "Jean", "jean@email.com", "+229XXXXXXXX", "2026-03-30", "Actif"],
    ["Martin", "Paul", "paul@email.com", "+229XXXXXXXX", "2026-03-30", "Actif"],
    ["Durand", "Marie", "marie@email.com", "+229XXXXXXXX", "2026-03-30", "Actif"]
]

for i, client in enumerate(clients, 2):
    for j, value in enumerate(client, 1):
        ws.cell(row=i, column=j, value=value)

# Ajuster largeur colonnes
for col in range(1, 7):
    ws.column_dimensions[chr(64+col)].width = 15

filename = f"C:\\Users\\DELL\\Desktop\\clients_pro_{datetime.datetime.now().strftime('%Y%m%d')}.xlsx"
wb.save(filename)
print(f"Excel avancé créé : {filename}")