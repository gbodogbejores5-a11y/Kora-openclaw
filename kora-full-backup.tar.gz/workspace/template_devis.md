\# 🌊 AFRICA GOLDEN DIGITAL



\## DEVIS



\---



\### INFORMATIONS



| | |

|---|---|

| \*\*Devis N°\*\* | {{numero}} |

| \*\*Date\*\* | {{date}} |

| \*\*Client\*\* | {{client}} |

| \*\*Validité\*\* | 30 jours |



\---



\### DÉTAIL DES PRESTATIONS



| Service | Montant (FCFA) |

|---------|----------------|

{{services}}



\---



\### TOTAL



\*\*{{total}} FCFA\*\*



\---



\### CONDITIONS



\- Devis valable 30 jours

\- Paiement à réception



\---



\*\*KORA 🌊\*\* - WhatsApp: +2290149308718

