#!/usr/bin/env python3
"""
Facture PDF Professionnelle - TVA configurable (défaut: 18%)
Créé pour KORA - Africa Golden Digital
"""

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib.enums import TA_CENTER, TA_RIGHT, TA_LEFT
import datetime
import sys
import random

# ==================== PALETTES ====================
PALETTES = [
    {"primary": "#1E3A5F", "secondary": "#2E5A8A", "gold": "#C9A87C", "light": "#F5F7FA"},
    {"primary": "#1F4A3C", "secondary": "#2E6A55", "gold": "#D4AF7A", "light": "#F4F8F2"},
    {"primary": "#0B3B5F", "secondary": "#1B5A7F", "gold": "#E5B85C", "light": "#F0F5FA"},
    {"primary": "#7A2E2E", "secondary": "#9E4A4A", "gold": "#E5B85C", "light": "#FEF5F5"},
    {"primary": "#2C6B4A", "secondary": "#4C8B6A", "gold": "#E5B85C", "light": "#F0F7F2"},
]

def get_palette():
    return random.choice(PALETTES)

def format_number(n):
    return f"{n:,.0f}".replace(",", " ")

def nombre_en_lettres(n):
    """Convertit un nombre en lettres"""
    if n == 0:
        return "ZÉRO"
    
    unites = ["", "UN", "DEUX", "TROIS", "QUATRE", "CINQ", "SIX", "SEPT", "HUIT", "NEUF", 
              "DIX", "ONZE", "DOUZE", "TREIZE", "QUATORZE", "QUINZE", "SEIZE", 
              "DIX-SEPT", "DIX-HUIT", "DIX-NEUF"]
    dizaines = ["", "DIX", "VINGT", "TRENTE", "QUARANTE", "CINQUANTE", 
                "SOIXANTE", "SOIXANTE-DIX", "QUATRE-VINGT", "QUATRE-VINGT-DIX"]
    
    if n < 20:
        return unites[n]
    elif n < 100:
        d = n // 10
        u = n % 10
        if d == 7:
            return "SOIXANTE-" + unites[10 + u] if u else "SOIXANTE"
        elif d == 9:
            return "QUATRE-VINGT-" + unites[10 + u] if u else "QUATRE-VINGT"
        elif u == 0:
            return dizaines[d]
        elif u == 1 and d != 8:
            return dizaines[d] + "-ET-UN"
        else:
            return dizaines[d] + "-" + unites[u]
    elif n < 1000:
        c = n // 100
        r = n % 100
        if c == 1:
            return "CENT" + ((" " + nombre_en_lettres(r)) if r else "")
        else:
            return unites[c] + " CENT" + ((" " + nombre_en_lettres(r)) if r else "")
    else:
        return "MILLE" + ((" " + nombre_en_lettres(n % 1000)) if n % 1000 else "")

def create_facture_pdf(client_name, amount, description, services=None, tva=18, remise=0):
    """Crée une facture PDF avec TVA configurable (défaut: 18%)"""
    
    palette = get_palette()
    facture_number = f"FACT-{datetime.datetime.now().strftime('%Y%m')}-{random.randint(1000, 9999)}"
    filename = f"C:\\Users\\DELL\\Desktop\\FACTURE_{client_name.replace(' ', '_')}_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.pdf"
    
    doc = SimpleDocTemplate(filename, pagesize=A4, topMargin=2*cm, bottomMargin=2*cm,
                            leftMargin=2*cm, rightMargin=2*cm)
    story = []
    styles = getSampleStyleSheet()
    
    # Styles personnalisés
    title_style = ParagraphStyle('TitleStyle', parent=styles['Normal'],
                                   fontSize=24, textColor=colors.HexColor(palette["primary"]),
                                   alignment=TA_LEFT, spaceAfter=5)
    facture_style = ParagraphStyle('FactureStyle', parent=styles['Normal'],
                                    fontSize=20, textColor=colors.HexColor(palette["gold"]),
                                    alignment=TA_RIGHT, spaceAfter=10)
    sub_style = ParagraphStyle('SubStyle', parent=styles['Normal'],
                                fontSize=10, textColor=colors.HexColor("#666666"),
                                alignment=TA_LEFT)
    section_style = ParagraphStyle('SectionStyle', parent=styles['Normal'],
                                    fontSize=12, textColor=colors.HexColor(palette["primary"]),
                                    alignment=TA_LEFT, spaceAfter=10, spaceBefore=20)
    
    # ============ EN-TÊTE ============
    story.append(Paragraph("🌊 AFRICA GOLDEN DIGITAL", title_style))
    story.append(Paragraph("FACTURE", facture_style))
    story.append(Spacer(1, 5))
    
    # Ligne décorative
    story.append(Paragraph("<hr color='#C9A87C' width='100%'/>", styles['Normal']))
    story.append(Spacer(1, 15))
    
    # ============ INFOS ENTREPRISE & FACTURE ============
    info_data = [
        ["Africa Golden Digital", f"FACTURE N° : {facture_number}"],
        ["Cotonou, Bénin", f"DATE : {datetime.datetime.now().strftime('%d/%m/%Y')}"],
        ["WhatsApp: +229 01 49 30 87 18", f"ÉCHÉANCE : {(datetime.datetime.now() + datetime.timedelta(days=30)).strftime('%d/%m/%Y')}"],
        ["Email: contact@africagoldendigital.com", ""],
    ]
    
    info_table = Table(info_data, colWidths=[8*cm, 8*cm])
    info_table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(info_table)
    story.append(Spacer(1, 20))
    
    # ============ CLIENT ============
    story.append(Paragraph("FACTURÉ À", section_style))
    client_data = [
        [f"<b>{client_name}</b>"],
        ["client@email.com"],
        ["+229 XX XX XX XX"],
    ]
    client_table = Table(client_data, colWidths=[16*cm])
    client_table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('TOPPADDING', (0, 0), (-1, -1), 4),
    ]))
    story.append(client_table)
    story.append(Spacer(1, 20))
    
    # ============ SERVICES ============
    story.append(Paragraph("DÉTAIL DES PRESTATIONS", section_style))
    
    if not services:
        services = [{"name": description, "qty": 1, "price": amount}]
    
    table_data = [['DÉSIGNATION', 'QTÉ', 'P.U. (FCFA)', 'MONTANT (FCFA)']]
    total_ht = 0
    for service in services:
        montant = service.get("qty", 1) * service.get("price", amount)
        total_ht += montant
        table_data.append([
            service["name"],
            str(service.get("qty", 1)),
            format_number(service.get("price", amount)),
            format_number(montant)
        ])
    
    service_table = Table(table_data, colWidths=[8*cm, 2.5*cm, 3*cm, 3.5*cm])
    service_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor(palette["primary"])),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('FONTSIZE', (0, 1), (-1, -1), 9),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#DDDDDD")),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
    ]))
    story.append(service_table)
    story.append(Spacer(1, 15))
    
    # ============ CALCULS ============
    # Sous-total
    calc_data = [["SOUS-TOTAL", "", "", format_number(total_ht)]]
    
    # Remise si applicable
    if remise > 0:
        montant_remise = total_ht * remise / 100
        total_ht -= montant_remise
        calc_data.append([f"REMISE ({remise}%)", "", "", f"-{format_number(montant_remise)}"])
    
    # TVA (seulement si > 0)
    if tva > 0:
        tva_amount = total_ht * tva / 100
        calc_data.append([f"TVA ({tva}%)", "", "", format_number(tva_amount)])
        total_ttc = total_ht + tva_amount
    else:
        tva_amount = 0
        total_ttc = total_ht
        calc_data.append(["TVA (0%)", "", "", "0"])
    
    calc_data.append(["", "", "TOTAL T.T.C.", format_number(total_ttc)])
    
    calc_table = Table(calc_data, colWidths=[8*cm, 2.5*cm, 3*cm, 3.5*cm])
    calc_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (0, -1), 'RIGHT'),
        ('ALIGN', (3, 0), (3, -1), 'RIGHT'),
        ('FONTNAME', (0, 0), (-1, -2), 'Helvetica'),
        ('FONTNAME', (3, -1), (3, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (3, -1), (3, -1), 12),
        ('TEXTCOLOR', (3, -1), (3, -1), colors.HexColor(palette["gold"])),
        ('TOPPADDING', (0, 0), (-1, -1), 5),
    ]))
    story.append(calc_table)
    story.append(Spacer(1, 15))
    
    # Montant en lettres
    montant_lettres = nombre_en_lettres(int(total_ttc))
    story.append(Paragraph(f"<i>Arrêtée la présente facture à la somme de : {montant_lettres} francs CFA</i>", 
                          ParagraphStyle('Italic', parent=styles['Normal'], fontSize=9, textColor=colors.HexColor("#666666"))))
    story.append(Spacer(1, 20))
    
    # ============ CONDITIONS ============
    story.append(Paragraph("CONDITIONS DE PAIEMENT", section_style))
    story.append(Paragraph("Paiement à réception sous 30 jours. En cas de retard, une pénalité de 10% sera appliquée.", 
                          ParagraphStyle('Normal', parent=styles['Normal'], fontSize=9, textColor=colors.HexColor("#888888"))))
    story.append(Spacer(1, 30))
    
    # ============ PIED ============
    story.append(Paragraph("📱 WhatsApp: +2290149308718 | 📧 contact@africagoldendigital.com", 
                          ParagraphStyle('Footer', parent=styles['Normal'], fontSize=8, textColor=colors.HexColor("#999999"), alignment=TA_CENTER)))
    story.append(Paragraph("Merci de votre confiance - KORA 🌊", 
                          ParagraphStyle('Footer2', parent=styles['Normal'], fontSize=9, textColor=colors.HexColor(palette["gold"]), alignment=TA_CENTER)))
    
    # ============ GÉNÉRATION ============
    doc.build(story)
    print(f"✅ FACTURE PDF CRÉÉE")
    print(f"   📁 {filename}")
    print(f"   🎨 Palette: {palette['primary']}")
    print(f"   💰 Montant: {format_number(total_ttc)} FCFA")
    print(f"   📊 TVA: {tva}%")
    print(f"   📅 Échéance: +30 jours")
    return filename

def main():
    if len(sys.argv) < 3:
        print("\n" + "="*60)
        print("🏢 GÉNÉRATEUR DE FACTURE PDF")
        print("="*60)
        print("\nUtilisation:")
        print("  python facture_pdf_pro.py <client> <montant> [description] [tva]")
        print("\nExemples:")
        print("  python facture_pdf_pro.py 'Jean Dupont' 150000 'Automatisation WhatsApp'")
        print("  python facture_pdf_pro.py 'Jean Dupont' 150000 'Automatisation WhatsApp' 0")
        print("  python facture_pdf_pro.py 'Jean Dupont' 150000 'Automatisation WhatsApp' 18")
        print("\nTVA par défaut: 18%")
        print("Pour pas de TVA: mettre 0")
        print("="*60)
        sys.exit(1)
    
    client = sys.argv[1]
    amount = int(sys.argv[2])
    description = sys.argv[3] if len(sys.argv) > 3 else "Prestation de services"
    tva = int(sys.argv[4]) if len(sys.argv) > 4 else 18  # 18% par défaut
    
    services = [{"name": description, "qty": 1, "price": amount}]
    
    print("\n" + "="*60)
    print("🏢 AFRICA GOLDEN DIGITAL - FACTURATION")
    print("="*60 + "\n")
    
    create_facture_pdf(client, amount, description, services=services, tva=tva)
    
    print("\n" + "="*60)
    print("✅ FACTURE GÉNÉRÉE AVEC SUCCÈS")
    print("📁 Fichier disponible sur votre Bureau")
    print("="*60 + "\n")

if __name__ == "__main__":
    main()