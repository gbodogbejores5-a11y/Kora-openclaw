from docx import Document
from docx.shared import Inches
import datetime

doc = Document()
doc.add_heading('Rapport d\'Activité', 0)

doc.add_heading('Résumé', level=1)
doc.add_paragraph('Ce rapport présente les activités de Africa Golden Digital pour le mois de Mars 2026.')

doc.add_heading('Clients', level=1)
doc.add_paragraph('• Jean Dupont - Actif\n• Paul Martin - Actif\n• Marie Durand - Actif')

doc.add_heading('Services Demandés', level=1)
doc.add_paragraph('• Automatisation WhatsApp\n• Création de contenu\n• Formation IA')

doc.add_heading('Prochaines Étapes', level=1)
doc.add_paragraph('• Développer l\'offre Excel/PPT\n• Former les nouveaux clients\n• Automatiser les rapports')

doc.add_paragraph(f'Généré par Kora - {datetime.datetime.now().strftime("%d/%m/%Y")}')

filename = f"C:\\Users\\DELL\\Desktop\\rapport_{datetime.datetime.now().strftime('%Y%m%d')}.docx"
doc.save(filename)
print(f"Word créé : {filename}")