from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
import datetime
import random

def random_color():
    return RGBColor(random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))

doc = Document()

# Titre principal
title = doc.add_heading(f'Rapport KORA - {datetime.datetime.now().strftime("%d/%m/%Y")}', 0)
title.alignment = WD_ALIGN_PARAGRAPH.CENTER
title.runs[0].font.color.rgb = random_color()

# Introduction
doc.add_heading('📋 Résumé', level=1)
doc.add_paragraph('Ce rapport présente les activités de Africa Golden Digital pour la période en cours.')

# Chiffres
doc.add_heading('📊 Chiffres Clés', level=1)
table = doc.add_table(rows=5, cols=2)
table.style = 'Table Grid'
data = [
    ('Nouveaux clients', '7'),
    ('Chiffre d\'affaires', '1 555 000 FCFA'),
    ('Taux de satisfaction', '95%'),
    ('Projets en cours', '8'),
    ('Clients actifs', '12')
]
for i, (key, value) in enumerate(data):
    table.cell(i, 0).text = key
    table.cell(i, 1).text = value
    table.cell(i, 0).paragraphs[0].runs[0].font.bold = True

# Services
doc.add_heading('💼 Services Proposés', level=1)
services = [
    '🤖 Automatisation WhatsApp - Gestion clients automatique',
    '🎓 Formation IA - Former vos équipes',
    '📊 Tableaux de bord - Suivi en temps réel',
    '📄 Création PDF/Excel/PPT - Documents professionnels',
    '📧 Gestion emails - Envoi automatique',
    '📱 Support client 24/7 - Disponibilité permanente'
]
for s in services:
    doc.add_paragraph(s, style='List Bullet')

# Performances
doc.add_heading('🚀 Performances', level=1)
perfs = [
    '⚡ Réponse clients : Moins de 10 secondes',
    '📈 Conversion : 75% des prospects',
    '🔄 Relances automatiques : 100%',
    '💡 Satisfaction client : 95%'
]
for p in perfs:
    doc.add_paragraph(p, style='List Bullet')

# Prochaines étapes
doc.add_heading('🎯 Prochaines Étapes', level=1)
steps = [
    '✅ Déploiement serveur 24h/24',
    '✅ Intégration Google Calendar',
    '✅ Templates automatiques',
    '✅ Formation des nouveaux clients'
]
for step in steps:
    doc.add_paragraph(step, style='List Bullet')

# Contact
doc.add_heading('📞 Contact', level=1)
doc.add_paragraph('KORA - Assistante IA')
doc.add_paragraph('WhatsApp : +2290149308718')
doc.add_paragraph('Email : contact@africagoldendigital.com')

# Signature
doc.add_paragraph(f'\n\nRapport généré par KORA 🌊 le {datetime.datetime.now().strftime("%d/%m/%Y à %H:%M")}')

filename = f"C:\\Users\\DELL\\Desktop\\KORA_Rapport_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.docx"
doc.save(filename)
print(f"✅ Word pro créé : {filename}")