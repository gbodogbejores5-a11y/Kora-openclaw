#!/usr/bin/env python3
"""
Génère une facture professionnelle en PDF
Créé pour KORA - Africa Golden Digital
"""

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.pdfgen import canvas
import datetime
import sys
import os
import random

def create_facture_pdf(client_name, amount, description="Prestation de services", facture_number=None):
    """Crée une facture PDF professionnelle"""
    
    if not facture_number:
        facture_number = f"FACT-{datetime.datetime.now().strftime('%Y%m')}-{random.randint(100, 999)}"
    
    filename = f"C:\\Users\\DELL\\Desktop\\facture_{client_name.replace(' ', '_')}_{datetime.datetime.now().strftime('%Y%m%d')}.pdf"
    
    doc = SimpleDocTemplate(filename, pagesize=A4, topMargin=2*cm, bottomMargin=2*cm)
    styles = getSampleStyleSheet()
    story = []
    
    # Style personnalisé
    title_style = ParagraphStyle(
        'TitleStyle',
        parent=styles['Heading1'],
        fontSize=18,
        textColor=colors.HexColor('#2E86C1'),
        alignment=1,
        spaceAfter=20
    )
    
    # En-tête
    story.append(Paragraph("🌊 AFRICA GOLDEN DIGITAL", title_style))
    story.append(Paragraph("FACTURE", styles['Heading2']))
    story.append(Spacer(1, 20))
    
    # Informations
    info_data = [
        ["Facture N°:", facture_number],
        ["Date:", datetime.datetime.now().strftime('%d/%m/%Y')],
        ["Client:", client_name],
    ]
    
    info_table = Table(info_data, colWidths=[3*cm, 10*cm])
    info_table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 0), (-1, -1), 11),
        ('ALIGN', (0, 0), (0, -1), 'RIGHT'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(info_table)
    story.append(Spacer(1, 20))
    
    # Tableau des services
    data = [
        ['Désignation', 'Qté', 'Prix unitaire', 'Montant'],
        [description, '1', f'{amount:,} FCFA', f'{amount:,} FCFA'],
    ]
    
    table = Table(data, colWidths=[8*cm, 2*cm, 3*cm, 3*cm])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#3498DB')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 12),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#F8F9FA')),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
    ]))
    story.append(table)
    story.append(Spacer(1, 20))
    
    # Total
    total_style = ParagraphStyle(
        'TotalStyle',
        parent=styles['Normal'],
        fontSize=14,
        textColor=colors.HexColor('#2E86C1'),
        alignment=2,
        spaceAfter=20
    )
    story.append(Paragraph(f"TOTAL à payer : {amount:,} FCFA", total_style))
    
    # Pied de page
    footer_style = ParagraphStyle(
        'FooterStyle',
        parent=styles['Normal'],
        fontSize=9,
        textColor=colors.grey,
        alignment=1,
        spaceBefore=50
    )
    story.append(Paragraph("Paiement à recevoir sous 30 jours. Merci de votre confiance.", footer_style))
    story.append(Paragraph("KORA 🌊 - Assistante IA - WhatsApp: +2290149308718", footer_style))
    
    doc.build(story)
    print(f"✅ Facture PDF créée : {filename}")
    return filename

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Utilisation: python create_facture_pdf.py <client> <montant> [description]")
        print("Exemple: python create_facture_pdf.py 'Jean Dupont' 150000 'Automatisation WhatsApp'")
        sys.exit(1)
    
    client = sys.argv[1]
    amount = int(sys.argv[2])
    description = sys.argv[3] if len(sys.argv) > 3 else "Prestation de services"
    
    create_facture_pdf(client, amount, description)