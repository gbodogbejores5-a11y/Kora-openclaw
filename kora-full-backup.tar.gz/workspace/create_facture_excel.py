#!/usr/bin/env python3
"""
Génère une facture professionnelle en Excel (.xlsx)
Créé pour KORA - Africa Golden Digital
"""

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
import datetime
import sys
import os

def create_facture(client_name, amount, description="Prestation de services", facture_number=None):
    """Crée une facture Excel professionnelle"""
    
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Facture"
    
    # Styles
    title_font = Font(bold=True, size=16, color="FFFFFF")
    title_fill = PatternFill(start_color="2E86C1", end_color="2E86C1", fill_type="solid")
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="3498DB", end_color="3498DB", fill_type="solid")
    border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    # Numéro de facture
    if not facture_number:
        facture_number = f"FACT-{datetime.datetime.now().strftime('%Y%m')}-{random.randint(100, 999)}"
    
    # Logo / Titre
    ws.merge_cells('A1:F1')
    ws['A1'] = "🌊 AFRICA GOLDEN DIGITAL"
    ws['A1'].font = Font(bold=True, size=18, color="2E86C1")
    ws['A1'].alignment = Alignment(horizontal='center')
    
    # Facture
    ws.merge_cells('A2:F2')
    ws['A2'] = "FACTURE"
    ws['A2'].font = Font(bold=True, size=14)
    ws['A2'].alignment = Alignment(horizontal='center')
    
    # Informations
    ws['A4'] = "Facture N° :"
    ws['B4'] = facture_number
    ws['A5'] = "Date :"
    ws['B5'] = datetime.datetime.now().strftime('%d/%m/%Y')
    ws['A6'] = "Client :"
    ws['B6'] = client_name
    
    # En-têtes tableau
    headers = ["Désignation", "Quantité", "Prix unitaire", "Montant"]
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=8, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center')
        cell.border = border
    
    # Contenu
    ws.cell(row=9, column=1, value=description)
    ws.cell(row=9, column=2, value=1)
    ws.cell(row=9, column=3, value=amount)
    ws.cell(row=9, column=4, value=amount)
    
    # Total
    ws.merge_cells(f'A{11}:C{11}')
    ws[f'A{11}'] = "TOTAL à payer :"
    ws[f'A{11}'].font = Font(bold=True)
    ws[f'A{11}'].alignment = Alignment(horizontal='right')
    ws[f'D{11}'] = amount
    ws[f'D{11}'].font = Font(bold=True, color="2E86C1")
    
    # Pied de page
    ws.merge_cells(f'A{13}:F{13}')
    ws[f'A{13}'] = "Paiement à recevoir sous 30 jours. Merci de votre confiance."
    ws[f'A{13}'].font = Font(size=10)
    ws[f'A{13}'].alignment = Alignment(horizontal='center')
    
    ws.merge_cells(f'A{14}:F{14}')
    ws[f'A{14}'] = "KORA 🌊 - Assistante IA - WhatsApp: +2290149308718"
    ws[f'A{14}'].font = Font(size=9)
    ws[f'A{14}'].alignment = Alignment(horizontal='center')
    
    # Ajuster largeurs
    ws.column_dimensions['A'].width = 30
    ws.column_dimensions['B'].width = 12
    ws.column_dimensions['C'].width = 15
    ws.column_dimensions['D'].width = 15
    
    # Sauvegarde
    filename = f"C:\\Users\\DELL\\Desktop\\facture_{client_name.replace(' ', '_')}_{datetime.datetime.now().strftime('%Y%m%d')}.xlsx"
    wb.save(filename)
    print(f"✅ Facture Excel créée : {filename}")
    return filename

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Utilisation: python create_facture_excel.py <client> <montant> [description]")
        print("Exemple: python create_facture_excel.py 'Jean Dupont' 150000 'Automatisation WhatsApp'")
        sys.exit(1)
    
    client = sys.argv[1]
    amount = int(sys.argv[2])
    description = sys.argv[3] if len(sys.argv) > 3 else "Prestation de services"
    
    create_facture(client, amount, description)