#!/usr/bin/env python3
"""
Générateur de devis professionnel FINAL
Créé pour KORA - Africa Golden Digital
Fonctions : TVA facultative, Remise, Quantités, Couleurs aléatoires, Filigrane
"""

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib.enums import TA_CENTER, TA_RIGHT, TA_LEFT
from reportlab.pdfgen import canvas
import datetime
import random
import os
import json

# ==================== PALETTES DE COULEURS ====================
PALETTES = [
    {"nom": "Bleu", "primaire": "#1E3A5F", "secondaire": "#C9A87C", "fond": "#F5F7FA"},
    {"nom": "Vert", "primaire": "#1F4A3C", "secondaire": "#D4AF7A", "fond": "#F4F8F2"},
    {"nom": "Bordeaux", "primaire": "#7A2E2E", "secondaire": "#E5B85C", "fond": "#FEF5F5"},
    {"nom": "Violet", "primaire": "#4A2C5F", "secondaire": "#E5B85C", "fond": "#F0E8F8"},
    {"nom": "Orange", "primaire": "#E67E22", "secondaire": "#F1C40F", "fond": "#FEF5E7"},
    {"nom": "Turquoise", "primaire": "#16A085", "secondaire": "#F39C12", "fond": "#E8F8F5"},
    {"nom": "Rose", "primaire": "#C0392B", "secondaire": "#F5B041", "fond": "#FDEDEC"},
    {"nom": "Gris", "primaire": "#34495E", "secondaire": "#BDC3C7", "fond": "#F8F9F9"},
]

# Configuration par défaut
CONFIG = {
    "entreprise": "AFRICA GOLDEN DIGITAL",
    "slogan": "L'excellence digitale",
    "whatsapp": "+2290149308718",
    "email": "contact@africagoldendigital.com",
    "adresse": "Cotonou, Bénin",
    "tva_defaut": 18,
    "devise": "FCFA",
    "delai_paiement": 30,
    "conditions": "Devis valable 30 jours. Paiement à réception. En cas de retard, pénalité de 10%."
}

def format_number(n):
    """Formate un nombre avec séparateurs"""
    return f"{n:,.0f}".replace(",", " ")

def get_random_palette():
    """Retourne une palette aléatoire"""
    return random.choice(PALETTES)

def add_watermark(canvas, doc, palette, texte="AFRICA GOLDEN DIGITAL"):
    """Ajoute un filigrane"""
    canvas.saveState()
    canvas.setFillColor(colors.HexColor(palette["fond"]))
    canvas.setFont('Helvetica', 50)
    canvas.rotate(45)
    canvas.drawString(250, -100, texte)
    canvas.restoreState()

def create_devis(client_name, services, tva=None, remise=0, palette=None):
    """Crée un devis PDF professionnel"""
    
    # Choisir une palette aléatoire si non spécifiée
    if not palette:
        palette = get_random_palette()
    
    # TVA par défaut si non spécifiée
    if tva is None:
        tva = CONFIG["tva_defaut"]
    
    # Calcul des totaux
    total_ht = sum(s['qty'] * s['price'] for s in services)
    
    # Appliquer remise
    if remise > 0:
        montant_remise = total_ht * remise / 100
        total_ht -= montant_remise
    else:
        montant_remise = 0
    
    # TVA
    if tva > 0:
        tva_amount = total_ht * tva / 100
        total_ttc = total_ht + tva_amount
    else:
        tva_amount = 0
        total_ttc = total_ht
    
    # Numéro de devis
    devis_number = f"DEV-{datetime.datetime.now().strftime('%Y%m')}-{random.randint(100, 999)}"
    
    # Date d'échéance
    echeance = datetime.datetime.now() + datetime.timedelta(days=CONFIG["delai_paiement"])
    
    # Nom du fichier
    filename = f"C:\\Users\\DELL\\Desktop\\DEVIS_{client_name.replace(' ', '_')}_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.pdf"
    
    # Création du document
    doc = SimpleDocTemplate(filename, pagesize=A4, topMargin=2*cm, bottomMargin=2*cm,
                            leftMargin=2*cm, rightMargin=2*cm)
    story = []
    styles = getSampleStyleSheet()
    
    # Styles personnalisés
    title_style = ParagraphStyle('Title', parent=styles['Normal'],
                                   fontSize=24, textColor=colors.HexColor(palette["primaire"]),
                                   alignment=TA_CENTER, spaceAfter=5, fontName='Helvetica-Bold')
    sub_style = ParagraphStyle('Sub', parent=styles['Normal'],
                                 fontSize=10, textColor=colors.HexColor(palette["secondaire"]),
                                 alignment=TA_CENTER, spaceAfter=20)
    section_style = ParagraphStyle('Section', parent=styles['Normal'],
                                     fontSize=14, textColor=colors.HexColor(palette["primaire"]),
                                     spaceAfter=10, spaceBefore=20, fontName='Helvetica-Bold')
    
    # En-tête
    story.append(Paragraph(f"🌊 {CONFIG['entreprise']}", title_style))
    story.append(Paragraph(CONFIG['slogan'], sub_style))
    story.append(Spacer(1, 10))
    
    # Informations devis
    info_data = [
        ["DEVIS N°", devis_number],
        ["DATE", datetime.datetime.now().strftime('%d/%m/%Y')],
        ["ÉCHÉANCE", echeance.strftime('%d/%m/%Y')],
        ["CLIENT", client_name],
        ["STATUT", "En attente"]
    ]
    
    info_table = Table(info_data, colWidths=[4*cm, 8*cm])
    info_table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('ALIGN', (0, 0), (0, -1), 'RIGHT'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BACKGROUND', (1, 0), (1, -1), colors.HexColor(palette["fond"])),
        ('TEXTCOLOR', (1, 4), (1, 4), colors.HexColor("#E67E22")),
    ]))
    story.append(info_table)
    story.append(Spacer(1, 20))
    
    # Section services
    story.append(Paragraph("📋 DÉTAIL DES PRESTATIONS", section_style))
    
    # Tableau des services
    table_data = [['SERVICE', 'QTÉ', 'PRIX UNITAIRE', 'TOTAL']]
    for s in services:
        total_ligne = s['qty'] * s['price']
        table_data.append([
            s['name'],
            str(s['qty']),
            f"{format_number(s['price'])} {CONFIG['devise']}",
            f"{format_number(total_ligne)} {CONFIG['devise']}"
        ])
    
    service_table = Table(table_data, colWidths=[7*cm, 2*cm, 3.5*cm, 3.5*cm])
    service_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor(palette["primaire"])),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('FONTSIZE', (0, 1), (-1, -1), 9),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor("#CCCCCC")),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
    ]))
    story.append(service_table)
    story.append(Spacer(1, 15))
    
    # Récapitulatif des totaux
    recap_data = []
    recap_data.append(["Total HT", f"{format_number(total_ht)} {CONFIG['devise']}"])
    
    if remise > 0:
        recap_data.append([f"Remise ({remise}%)", f"-{format_number(montant_remise)} {CONFIG['devise']}"])
    
    if tva > 0:
        recap_data.append([f"TVA ({tva}%)", f"{format_number(tva_amount)} {CONFIG['devise']}"])
    else:
        recap_data.append(["TVA", "Exonéré"])
    
    recap_data.append(["TOTAL TTC", f"{format_number(total_ttc)} {CONFIG['devise']}"])
    
    recap_table = Table(recap_data, colWidths=[10*cm, 6*cm])
    recap_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (0, -1), 'RIGHT'),
        ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
        ('FONTNAME', (0, -1), (1, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, -1), (1, -1), 14),
        ('TEXTCOLOR', (0, -1), (1, -1), colors.HexColor(palette["secondaire"])),
        ('TOPPADDING', (0, 0), (-1, -1), 5),
        ('BACKGROUND', (0, -1), (1, -1), colors.HexColor(palette["fond"])),
    ]))
    story.append(recap_table)
    story.append(Spacer(1, 30))
    
    # Conditions
    story.append(Paragraph("📌 CONDITIONS", section_style))
    story.append(Paragraph(f"• {CONFIG['conditions']}", styles['Normal']))
    story.append(Paragraph(f"• Paiement à réception sous {CONFIG['delai_paiement']} jours", styles['Normal']))
    story.append(Spacer(1, 20))
    
    # Signature
    story.append(Paragraph("Signature précédée de la mention 'Bon pour accord'", 
                          ParagraphStyle('Sign', parent=styles['Normal'], fontSize=9, textColor=colors.grey)))
    
    story.append(Spacer(1, 30))
    
    # Pied de page
    footer_style = ParagraphStyle('Footer', parent=styles['Normal'],
                                   fontSize=8, textColor=colors.grey, alignment=TA_CENTER)
    story.append(Paragraph(f"📱 WhatsApp: {CONFIG['whatsapp']} | 📧 {CONFIG['email']} | 📍 {CONFIG['adresse']}", footer_style))
    story.append(Paragraph(f"🌊 {CONFIG['entreprise']} - Document généré automatiquement par KORA", footer_style))
    
    # Génération du PDF avec filigrane
    doc.build(story, onFirstPage=lambda c, d: add_watermark(c, d, palette, CONFIG['entreprise']),
                   onLaterPages=lambda c, d: add_watermark(c, d, palette, CONFIG['entreprise']))
    
    # Affichage du résultat
    print("\n" + "="*60)
    print(f"✨ DEVIS CRÉÉ AVEC SUCCÈS !")
    print("="*60)
    print(f"📄 PDF : {filename}")
    print(f"🎨 Palette : {palette['nom']}")
    print(f"💰 Total HT : {format_number(total_ht)} {CONFIG['devise']}")
    if tva > 0:
        print(f"💰 TVA ({tva}%) : {format_number(tva_amount)} {CONFIG['devise']}")
    print(f"💰 TOTAL TTC : {format_number(total_ttc)} {CONFIG['devise']}")
    print(f"🏷️  N° : {devis_number}")
    print(f"📅 Échéance : {echeance.strftime('%d/%m/%Y')}")
    print("="*60)
    
    # Sauvegarder l'historique
    historique = {
        "client": client_name,
        "numero": devis_number,
        "date": datetime.datetime.now().isoformat(),
        "total": total_ttc,
        "fichier": filename
    }
    
    historique_path = "C:\\Users\\DELL\\.openclaw\\workspace\\devis_historique.json"
    if os.path.exists(historique_path):
        with open(historique_path, 'r', encoding='utf-8') as f:
            hist = json.load(f)
    else:
        hist = []
    
    hist.append(historique)
    
    with open(historique_path, 'w', encoding='utf-8') as f:
        json.dump(hist, f, indent=2, ensure_ascii=False)
    
    return filename

def main():
    print("\n" + "="*60)
    print(f"✨ {CONFIG['entreprise']} - GÉNÉRATEUR DE DEVIS")
    print("="*60)
    print(f"🎨 Palette aléatoire parmi {len(PALETTES)} couleurs")
    print(f"💰 TVA: {CONFIG['tva_defaut']}% (modifiable)")
    print("="*60)
    
    # Saisie du client
    client = input("\n👤 Nom du client : ")
    
    # Saisie des services
    services = []
    i = 1
    print("\n📦 Saisie des services (tapez 'fin' pour terminer)")
    while True:
        print(f"\n--- Service {i} ---")
        name = input("  Nom du service : ")
        if name.lower() == 'fin':
            break
        try:
            qty = int(input("  Quantité : "))
            price = int(input("  Prix unitaire (FCFA) : "))
            services.append({"name": name, "qty": qty, "price": price})
            i += 1
        except ValueError:
            print("  ❌ Entrez des nombres valides")
    
    if not services:
        print("❌ Aucun service ajouté")
        return
    
    # Options
    print("\n⚙️ OPTIONS")
    tva_input = input(f"TVA (0-18, par défaut {CONFIG['tva_defaut']}%) : ")
    tva = int(tva_input) if tva_input else CONFIG['tva_defaut']
    
    remise_input = input("Remise (0-100, par défaut 0%) : ")
    remise = int(remise_input) if remise_input else 0
    
    # Création du devis
    create_devis(client, services, tva, remise)

if __name__ == "__main__":
    main()