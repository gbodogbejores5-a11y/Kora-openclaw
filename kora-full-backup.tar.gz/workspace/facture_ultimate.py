#!/usr/bin/env python3
"""
Facture professionnelle ULTIME - Version corrigée
Créé pour KORA - Africa Golden Digital
"""

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.chart import BarChart, Reference
import datetime
import sys
import os
import random

# ==================== PALETTES HARMONIEUSES ====================
PALETTES = [
    {"name": "Océan", "primary": "1E3A5F", "secondary": "2E5A8A", "accent": "3A7CA5", "light": "E8F0F8"},
    {"name": "Forêt", "primary": "1F4A3C", "secondary": "2E6A55", "accent": "4A8B6E", "light": "E8F2EF"},
    {"name": "Doré", "primary": "C47D2E", "secondary": "D89A4A", "accent": "ECB86A", "light": "FEF5E8"},
    {"name": "Violet", "primary": "4A2C5F", "secondary": "6A4C7F", "accent": "8A6C9F", "light": "F0E8F8"},
    {"name": "Saphir", "primary": "0B3B5F", "secondary": "1B5A7F", "accent": "2B7A9F", "light": "E5F0F8"},
    {"name": "Rubis", "primary": "8B2C2C", "secondary": "B84C4C", "accent": "E56C6C", "light": "FEF0F0"},
    {"name": "Émeraude", "primary": "2C6B4A", "secondary": "4C8B6A", "accent": "6CAB8A", "light": "E8F5EF"},
]

def get_palette():
    return random.choice(PALETTES)

# ==================== FACTURE EXCEL ====================
def create_facture_excel(client_name, amount, description, services=None, tva=18):
    palette = get_palette()
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Facture"
    
    primary_fill = PatternFill(start_color=palette["primary"], end_color=palette["primary"], fill_type="solid")
    light_fill = PatternFill(start_color=palette["light"], end_color=palette["light"], fill_type="solid")
    
    title_font = Font(bold=True, size=20, color=palette["primary"])
    header_font = Font(bold=True, size=11, color="FFFFFF")
    total_font = Font(bold=True, size=14, color=palette["accent"])
    
    border = Border(
        left=Side(style='thin', color="CCCCCC"),
        right=Side(style='thin', color="CCCCCC"),
        top=Side(style='thin', color="CCCCCC"),
        bottom=Side(style='thin', color="CCCCCC")
    )
    
    facture_number = f"FACT-{datetime.datetime.now().strftime('%Y%m')}-{random.randint(100, 999)}"
    
    # En-tête
    ws.merge_cells('A1:F1')
    ws['A1'] = "🌊 AFRICA GOLDEN DIGITAL"
    ws['A1'].font = title_font
    ws['A1'].alignment = Alignment(horizontal='center')
    
    ws.merge_cells('A2:F2')
    ws['A2'] = "FACTURE"
    ws['A2'].font = Font(bold=True, size=14, color=palette["secondary"])
    ws['A2'].alignment = Alignment(horizontal='center')
    
    # Informations
    ws['A4'] = "Facture N°"
    ws['A4'].font = Font(bold=True)
    ws['B4'] = facture_number
    ws['A5'] = "Date"
    ws['A5'].font = Font(bold=True)
    ws['B5'] = datetime.datetime.now().strftime('%d/%m/%Y')
    ws['A6'] = "Client"
    ws['A6'].font = Font(bold=True)
    ws['B6'] = client_name
    
    ws['D4'] = "Échéance"
    ws['D4'].font = Font(bold=True)
    ws['E4'] = (datetime.datetime.now() + datetime.timedelta(days=30)).strftime('%d/%m/%Y')
    
    # Tableau
    headers = ["Désignation", "Qté", "P.U. (FCFA)", "Montant (FCFA)"]
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=8, column=col, value=header)
        cell.font = header_font
        cell.fill = primary_fill
        cell.alignment = Alignment(horizontal='center')
        cell.border = border
    
    if not services:
        services = [{"name": description, "qty": 1, "price": amount}]
    
    total_ht = 0
    row = 9
    for service in services:
        ws.cell(row=row, column=1, value=service["name"])
        ws.cell(row=row, column=2, value=service.get("qty", 1))
        ws.cell(row=row, column=3, value=service.get("price", amount))
        montant = service.get("qty", 1) * service.get("price", amount)
        ws.cell(row=row, column=4, value=montant)
        total_ht += montant
        row += 1
    
    tva_amount = total_ht * tva / 100
    total_ttc = total_ht + tva_amount
    
    ws.merge_cells(f'A{row+2}:C{row+2}')
    ws[f'A{row+2}'] = "TOTAL H.T."
    ws[f'A{row+2}'].font = Font(bold=True)
    ws[f'A{row+2}'].alignment = Alignment(horizontal='right')
    ws[f'D{row+2}'] = total_ht
    
    ws.merge_cells(f'A{row+3}:C{row+3}')
    ws[f'A{row+3}'] = f"TVA ({tva}%)"
    ws[f'A{row+3}'].font = Font(bold=True)
    ws[f'A{row+3}'].alignment = Alignment(horizontal='right')
    ws[f'D{row+3}'] = tva_amount
    
    ws.merge_cells(f'A{row+4}:C{row+4}')
    ws[f'A{row+4}'] = "TOTAL T.T.C."
    ws[f'A{row+4}'].font = total_font
    ws[f'A{row+4}'].alignment = Alignment(horizontal='right')
    ws[f'D{row+4}'] = total_ttc
    ws[f'D{row+4}'].fill = light_fill
    
    # Pied de page
    ws.merge_cells(f'A{row+6}:F{row+6}')
    ws[f'A{row+6}'] = "📱 WhatsApp : +2290149308718 | 📧 contact@africagoldendigital.com"
    ws[f'A{row+6}'].font = Font(size=9, color="666666")
    ws[f'A{row+6}'].alignment = Alignment(horizontal='center')
    
    ws.merge_cells(f'A{row+7}:F{row+7}')
    ws[f'A{row+7}'] = "Merci de votre confiance. Paiement à recevoir sous 30 jours."
    ws[f'A{row+7}'].font = Font(size=9, italic=True, color="666666")
    ws[f'A{row+7}'].alignment = Alignment(horizontal='center')
    
    ws.merge_cells(f'A{row+8}:F{row+8}')
    ws[f'A{row+8}'] = "Généré par KORA 🌊"
    ws[f'A{row+8}'].font = Font(size=8, color="999999")
    ws[f'A{row+8}'].alignment = Alignment(horizontal='center')
    
    # Ajustement
    ws.column_dimensions['A'].width = 35
    ws.column_dimensions['B'].width = 10
    ws.column_dimensions['C'].width = 15
    ws.column_dimensions['D'].width = 18
    
    filename = f"C:\\Users\\DELL\\Desktop\\Facture_{client_name.replace(' ', '_')}_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
    wb.save(filename)
    print(f"✅ Facture Excel créée : {filename}")
    return filename

# ==================== FACTURE PDF ====================
def create_facture_pdf(client_name, amount, description, services=None, tva=18):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.lib.enums import TA_CENTER
    
    palette = get_palette()
    
    facture_number = f"FACT-{datetime.datetime.now().strftime('%Y%m')}-{random.randint(100, 999)}"
    filename = f"C:\\Users\\DELL\\Desktop\\Facture_{client_name.replace(' ', '_')}_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.pdf"
    
    doc = SimpleDocTemplate(filename, pagesize=A4, topMargin=2*cm, bottomMargin=2*cm)
    story = []
    styles = getSampleStyleSheet()
    
    title_style = ParagraphStyle('TitleStyle', parent=styles['Heading1'],
                                  fontSize=22, textColor=colors.HexColor("#" + palette["primary"]),
                                  alignment=TA_CENTER, spaceAfter=20)
    header_style = ParagraphStyle('HeaderStyle', parent=styles['Heading2'],
                                   fontSize=12, textColor=colors.HexColor("#" + palette["secondary"]),
                                   spaceAfter=10)
    
    story.append(Paragraph("🌊 AFRICA GOLDEN DIGITAL", title_style))
    story.append(Paragraph("FACTURE", header_style))
    story.append(Spacer(1, 20))
    
    info_data = [
        ["Facture N°:", facture_number, "Client:", client_name],
        ["Date:", datetime.datetime.now().strftime('%d/%m/%Y'), "Échéance:", (datetime.datetime.now() + datetime.timedelta(days=30)).strftime('%d/%m/%Y')],
    ]
    
    info_table = Table(info_data, colWidths=[3*cm, 4*cm, 3*cm, 6*cm])
    info_table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('ALIGN', (0, 0), (1, -1), 'RIGHT'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
    ]))
    story.append(info_table)
    story.append(Spacer(1, 20))
    
    if not services:
        services = [{"name": description, "qty": 1, "price": amount}]
    
    table_data = [['Désignation', 'Qté', 'P.U. (FCFA)', 'Montant (FCFA)']]
    total_ht = 0
    for service in services:
        montant = service.get("qty", 1) * service.get("price", amount)
        total_ht += montant
        table_data.append([service["name"], str(service.get("qty", 1)), f"{service.get('price', amount):,}", f"{montant:,}"])
    
    tva_amount = total_ht * tva / 100
    total_ttc = total_ht + tva_amount
    
    table_data.append(["", "", "TOTAL H.T.", f"{total_ht:,}"])
    table_data.append(["", "", f"TVA ({tva}%)", f"{tva_amount:,}"])
    table_data.append(["", "", "TOTAL T.T.C.", f"{total_ttc:,}"])
    
    service_table = Table(table_data, colWidths=[8*cm, 2*cm, 3*cm, 3*cm])
    service_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor("#" + palette["primary"])),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 11),
        ('GRID', (0, 0), (-1, -4), 1, colors.HexColor("#CCCCCC")),
        ('BACKGROUND', (2, -3), (-1, -1), colors.HexColor("#" + palette["light"])),
        ('FONTNAME', (2, -3), (-1, -1), 'Helvetica-Bold'),
    ]))
    story.append(service_table)
    story.append(Spacer(1, 20))
    
    footer_style = ParagraphStyle('FooterStyle', parent=styles['Normal'],
                                   fontSize=9, textColor=colors.grey, alignment=TA_CENTER)
    story.append(Paragraph("Merci de votre confiance. Paiement à recevoir sous 30 jours.", footer_style))
    story.append(Paragraph("📱 WhatsApp : +2290149308718 | 📧 contact@africagoldendigital.com", footer_style))
    story.append(Paragraph("Généré par KORA 🌊", footer_style))
    
    doc.build(story)
    print(f"✅ Facture PDF créée : {filename}")
    return filename

# ==================== MAIN ====================
def main():
    if len(sys.argv) < 3:
        print("Utilisation: python facture_ultimate.py <client> <montant> [description]")
        print("Exemple: python facture_ultimate.py 'Jean Dupont' 150000 'Automatisation WhatsApp'")
        sys.exit(1)
    
    client = sys.argv[1]
    amount = int(sys.argv[2])
    description = sys.argv[3] if len(sys.argv) > 3 else "Prestation de services"
    
    services = [{"name": description, "qty": 1, "price": amount}]
    
    print("\n" + "="*50)
    print("🏢 GÉNÉRATION DE FACTURE")
    print("="*50 + "\n")
    
    create_facture_excel(client, amount, description, services)
    create_facture_pdf(client, amount, description, services)
    
    print("\n" + "="*50)
    print("✅ FACTURES CRÉÉES AVEC SUCCÈS !")
    print("📁 Sur le Bureau")
    print("="*50)

if __name__ == "__main__":
    main()