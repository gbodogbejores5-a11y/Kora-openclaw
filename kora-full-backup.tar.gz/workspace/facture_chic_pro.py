#!/usr/bin/env python3
"""
Facture ULTRA PRO - Structure parfaite, calculs précis, design chic
Créé pour KORA - Africa Golden Digital
"""

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
import datetime
import sys
import random

# ==================== PALETTES PROFESSIONNELLES ====================
PALETTES = [
    {"name": "Océan Luxe", "primary": "1E3A5F", "secondary": "2E5A8A", "accent": "4A7B9D", "gold": "C9A87C", "light": "F5F7FA"},
    {"name": "Forêt Prestige", "primary": "1F4A3C", "secondary": "2E6A55", "accent": "5A8F6E", "gold": "D4AF7A", "light": "F4F8F2"},
    {"name": "Saphir Royal", "primary": "0B3B5F", "secondary": "1B5A7F", "accent": "2B7A9F", "gold": "E5B85C", "light": "F0F5FA"},
    {"name": "Rubis Élégant", "primary": "7A2E2E", "secondary": "9E4A4A", "accent": "C26A6A", "gold": "E5B85C", "light": "FEF5F5"},
    {"name": "Émeraude Chic", "primary": "2C6B4A", "secondary": "4C8B6A", "accent": "6CAB8A", "gold": "E5B85C", "light": "F0F7F2"},
]

def get_palette():
    return random.choice(PALETTES)

def format_number(number):
    return f"{number:,.0f}".replace(",", " ")

def create_facture_pro(client_name, amount, description, services=None, tva=18, remise=0):
    palette = get_palette()
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "FACTURE"
    
    # Styles
    title_font = Font(name='Segoe UI', bold=True, size=24, color=palette["primary"])
    sub_font = Font(name='Segoe UI', size=10, color="666666")
    header_font = Font(name='Segoe UI', bold=True, size=11, color="FFFFFF")
    text_font = Font(name='Segoe UI', size=10)
    bold_font = Font(name='Segoe UI', bold=True, size=10)
    total_font = Font(name='Segoe UI', bold=True, size=14, color=palette["gold"])
    
    primary_fill = PatternFill(start_color=palette["primary"], end_color=palette["primary"], fill_type="solid")
    gold_fill = PatternFill(start_color=palette["gold"], end_color=palette["gold"], fill_type="solid")
    light_fill = PatternFill(start_color=palette["light"], end_color=palette["light"], fill_type="solid")
    
    thin_border = Border(
        left=Side(style='thin', color="DDDDDD"),
        right=Side(style='thin', color="DDDDDD"),
        top=Side(style='thin', color="DDDDDD"),
        bottom=Side(style='thin', color="DDDDDD")
    )
    
    facture_number = f"FACT-{datetime.datetime.now().strftime('%Y%m')}-{random.randint(1000, 9999)}"
    
    # ============ SECTION 1 : LOGO & TITRE ============
    ws.merge_cells('A1:E1')
    ws['A1'] = "🌊 AFRICA GOLDEN DIGITAL"
    ws['A1'].font = title_font
    ws['A1'].alignment = Alignment(horizontal='left')
    ws.row_dimensions[1].height = 35
    
    ws['F1'] = "FACTURE"
    ws['F1'].font = Font(name='Segoe UI', bold=True, size=20, color=palette["gold"])
    ws['F1'].alignment = Alignment(horizontal='right')
    
    ws.merge_cells('A2:F2')
    ws['A2'].border = Border(bottom=Side(style='medium', color=palette["gold"]))
    ws.row_dimensions[2].height = 5
    
    # ============ SECTION 2 : ADRESSE & INFO ============
    ws['A4'] = "Africa Golden Digital"
    ws['A4'].font = bold_font
    ws['A5'] = "Cotonou, Bénin"
    ws['A5'].font = sub_font
    ws['A6'] = "WhatsApp: +229 01 49 30 87 18"
    ws['A6'].font = sub_font
    ws['A7'] = "Email: contact@africagoldendigital.com"
    ws['A7'].font = sub_font
    
    ws['E4'] = "FACTURE N°"
    ws['E4'].font = bold_font
    ws['E4'].alignment = Alignment(horizontal='right')
    ws['F4'] = facture_number
    ws['F4'].font = bold_font
    ws['F4'].alignment = Alignment(horizontal='left')
    
    ws['E5'] = "DATE"
    ws['E5'].font = bold_font
    ws['E5'].alignment = Alignment(horizontal='right')
    ws['F5'] = datetime.datetime.now().strftime('%d/%m/%Y')
    
    ws['E6'] = "ÉCHÉANCE"
    ws['E6'].font = bold_font
    ws['E6'].alignment = Alignment(horizontal='right')
    ws['F6'] = (datetime.datetime.now() + datetime.timedelta(days=30)).strftime('%d/%m/%Y')
    
    # ============ SECTION 3 : CLIENT ============
    ws.merge_cells('A9:C9')
    ws['A9'] = "FACTURÉ À"
    ws['A9'].font = Font(name='Segoe UI', bold=True, size=12, color=palette["primary"])
    
    ws['A10'] = client_name
    ws['A10'].font = bold_font
    ws['A11'] = "client@email.com"
    ws['A11'].font = sub_font
    ws['A12'] = "+229 XX XX XX XX"
    ws['A12'].font = sub_font
    
    # ============ SECTION 4 : TABLEAU ============
    headers = ["DÉSIGNATION", "QUANTITÉ", "PRIX UNITAIRE (FCFA)", "MONTANT (FCFA)"]
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=14, column=col, value=header)
        cell.font = header_font
        cell.fill = primary_fill
        cell.alignment = Alignment(horizontal='center')
        cell.border = thin_border
    
    if not services:
        services = [{"name": description, "qty": 1, "price": amount}]
    
    total_ht = 0
    row = 15
    for service in services:
        qty = service.get("qty", 1)
        price = service.get("price", amount)
        montant = qty * price
        total_ht += montant
        
        ws.cell(row=row, column=1, value=service["name"])
        ws.cell(row=row, column=2, value=qty)
        ws.cell(row=row, column=3, value=price)
        ws.cell(row=row, column=4, value=montant)
        
        for col in range(1, 5):
            cell = ws.cell(row=row, column=col)
            cell.font = text_font
            cell.border = thin_border
            cell.alignment = Alignment(horizontal='center' if col > 1 else 'left')
        row += 1
    
    # ============ SECTION 5 : CALCULS ============
    ws.merge_cells(f'B{row+2}:C{row+2}')
    ws[f'B{row+2}'] = "SOUS-TOTAL"
    ws[f'B{row+2}'].font = bold_font
    ws[f'B{row+2}'].alignment = Alignment(horizontal='right')
    ws[f'D{row+2}'] = total_ht
    
    if remise > 0:
        montant_remise = total_ht * remise / 100
        ws.merge_cells(f'B{row+3}:C{row+3}')
        ws[f'B{row+3}'] = f"REMISE ({remise}%)"
        ws[f'B{row+3}'].font = text_font
        ws[f'B{row+3}'].alignment = Alignment(horizontal='right')
        ws[f'D{row+3}'] = -montant_remise
        total_ht -= montant_remise
        row += 1
    
    tva_amount = total_ht * tva / 100
    ws.merge_cells(f'B{row+3}:C{row+3}')
    ws[f'B{row+3}'] = f"TVA ({tva}%)"
    ws[f'B{row+3}'].font = text_font
    ws[f'B{row+3}'].alignment = Alignment(horizontal='right')
    ws[f'D{row+3}'] = tva_amount
    
    total_ttc = total_ht + tva_amount
    ws.merge_cells(f'B{row+4}:C{row+4}')
    ws[f'B{row+4}'] = "TOTAL T.T.C."
    ws[f'B{row+4}'].font = total_font
    ws[f'B{row+4}'].alignment = Alignment(horizontal='right')
    ws[f'D{row+4}'] = total_ttc
    ws[f'D{row+4}'].font = total_font
    ws[f'D{row+4}'].fill = light_fill
    
    # ============ SECTION 6 : PIED ============
    ws.merge_cells(f'A{row+7}:F{row+7}')
    ws[f'A{row+7}'] = "📱 WhatsApp: +2290149308718 | 📧 contact@africagoldendigital.com"
    ws[f'A{row+7}'].font = Font(size=9, color="888888")
    ws[f'A{row+7}'].alignment = Alignment(horizontal='center')
    
    ws.merge_cells(f'A{row+8}:F{row+8}')
    ws[f'A{row+8}'] = "Merci de votre confiance - KORA 🌊"
    ws[f'A{row+8}'].font = Font(size=9, italic=True, color=palette["gold"])
    ws[f'A{row+8}'].alignment = Alignment(horizontal='center')
    
    # Ajustements
    ws.column_dimensions['A'].width = 40
    ws.column_dimensions['B'].width = 12
    ws.column_dimensions['C'].width = 18
    ws.column_dimensions['D'].width = 18
    ws.column_dimensions['E'].width = 15
    ws.column_dimensions['F'].width = 15
    
    filename = f"C:\\Users\\DELL\\Desktop\\FACTURE_{client_name.replace(' ', '_')}_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
    wb.save(filename)
    print(f"✅ FACTURE PRO CRÉÉE")
    print(f"   📁 {filename}")
    print(f"   🎨 Palette: {palette['name']}")
    print(f"   💰 Montant: {format_number(total_ttc)} FCFA")
    return filename

def main():
    if len(sys.argv) < 3:
        print("\n🏢 GÉNÉRATEUR DE FACTURE PRO")
        print("\nUtilisation: python facture_chic_pro.py <client> <montant> [description]")
        print("Exemple: python facture_chic_pro.py 'Jean Dupont' 150000 'Automatisation WhatsApp'")
        sys.exit(1)
    
    client = sys.argv[1]
    amount = int(sys.argv[2])
    description = sys.argv[3] if len(sys.argv) > 3 else "Prestation de services"
    
    services = [{"name": description, "qty": 1, "price": amount}]
    
    create_facture_pro(client, amount, description, services=services)

if __name__ == "__main__":
    main()