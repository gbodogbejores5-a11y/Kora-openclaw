import speech_recognition as sr
import sys

def transcribe_audio(file_path):
    recognizer = sr.Recognizer()
    with sr.AudioFile(file_path) as source:
        audio = recognizer.record(source)
    try:
        text = recognizer.recognize_google(audio, language="fr-FR")
        return text
    except:
        return "Je n'ai pas pu transcrire ce message."

if __name__ == "__main__":
    if len(sys.argv) > 1:
        result = transcribe_audio(sys.argv[1])
        print(result)