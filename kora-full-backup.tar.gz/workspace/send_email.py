#!/usr/bin/env python3
"""
Script d'envoi d'emails via Gmail SMTP
Créé pour OpenClaw - Jores
"""

import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import sys
import os

def send_email(to_address, subject, body, attachment_path=None):
    """
    Envoie un email via Gmail SMTP
    """
    # Configuration Gmail
    smtp_server = "smtp.gmail.com"
    smtp_port = 587
    sender_email = "gbodogbejores5@gmail.com"
    # Mot de passe d'application fourni par Jores
    password = "sgcv jfdi llfh fdyg"
    
    # Création du message
    message = MIMEMultipart("alternative")
    message["Subject"] = subject
    message["From"] = sender_email
    message["To"] = to_address
    
    # Corps du message
    message.attach(MIMEText(body, "plain", "utf-8"))
    
    # Ajout de pièce jointe si fournie
    if attachment_path and os.path.exists(attachment_path):
        with open(attachment_path, "rb") as attachment:
            part = MIMEBase("application", "octet-stream")
            part.set_payload(attachment.read())
        encoders.encode_base64(part)
        part.add_header(
            "Content-Disposition",
            f"attachment; filename= {os.path.basename(attachment_path)}",
        )
        message.attach(part)
    
    # Envoi via SMTP
    try:
        context = ssl.create_default_context()
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls(context=context)
            server.login(sender_email, password.replace(" ", ""))
            server.sendmail(sender_email, to_address, message.as_string())
        print(f"✅ Email envoyé avec succès à {to_address}")
        return True
    except Exception as e:
        print(f"❌ Erreur lors de l'envoi : {e}")
        return False

def main():
    # Vérification des arguments
    if len(sys.argv) < 4:
        print("Usage: python send_email.py <destinataire> <sujet> <message> [pièce_jointe]")
        print("Exemple: python send_email.py contact@example.com 'Salut' 'Contenu du message'")
        sys.exit(1)
    
    to_address = sys.argv[1]
    subject = sys.argv[2]
    body = sys.argv[3]
    attachment = sys.argv[4] if len(sys.argv) > 4 else None
    
    # Envoi de l'email
    success = send_email(to_address, subject, body, attachment)
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()
