import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.drawing.image import Image
import datetime

wb = openpyxl.Workbook()
ws = wb.active
ws.title = "Rapport"

# Styles
title_font = Font(bold=True, color="FFFFFF", size=14)
title_fill = PatternFill(start_color="2E86C1", end_color="2E86C1", fill_type="solid")
header_font = Font(bold=True, color="FFFFFF")
header_fill = PatternFill(start_color="3498DB", end_color="3498DB", fill_type="solid")
border = Border(left=Side(style='thin'), right=Side(style='thin'),
                top=Side(style='thin'), bottom=Side(style='thin'))

# Titre
ws.merge_cells('A1:D1')
ws['A1'] = f"Rapport d'Activité - {datetime.datetime.now().strftime('%d/%m/%Y')}"
ws['A1'].font = title_font
ws['A1'].fill = title_fill
ws['A1'].alignment = Alignment(horizontal='center')

# En-têtes
headers = ['Client', 'Service', 'Montant', 'Statut']
for col, header in enumerate(headers, 1):
    cell = ws.cell(row=2, column=col, value=header)
    cell.font = header_font
    cell.fill = header_fill
    cell.alignment = Alignment(horizontal='center')
    cell.border = border

# Données
data = [
    ['Jean Dupont', 'Automatisation', '150 000 FCFA', 'Payé'],
    ['Paul Martin', 'Formation IA', '200 000 FCFA', 'En attente'],
    ['Marie Durand', 'Pack Entreprise', '500 000 FCFA', 'Validé'],
]

for i, row in enumerate(data, 3):
    for j, value in enumerate(row, 1):
        cell = ws.cell(row=i, column=j, value=value)
        cell.border = border
        cell.alignment = Alignment(horizontal='center')
        if value == 'Payé':
            cell.fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
        elif value == 'En attente':
            cell.fill = PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid")

# Ajuster largeurs
for col in range(1, 5):
    ws.column_dimensions[chr(64+col)].width = 20

filename = f"C:\\Users\\DELL\\Desktop\\rapport_style_{datetime.datetime.now().strftime('%Y%m%d')}.xlsx"
wb.save(filename)
print(f"Excel stylé créé : {filename}")