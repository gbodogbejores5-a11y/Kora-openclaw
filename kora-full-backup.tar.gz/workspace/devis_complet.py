#!/usr/bin/env python3
"""
Génère un devis complet : HTML + PDF
Créé pour KORA
"""

import datetime
import random
import os
import sys
from weasyprint import HTML

def nombre_en_lettres(n):
    if n == 0:
        return "ZÉRO"
    unites = ["", "UN", "DEUX", "TROIS", "QUATRE", "CINQ", "SIX", "SEPT", "HUIT", "NEUF", 
              "DIX", "ONZE", "DOUZE", "TREIZE", "QUATORZE", "QUINZE", "SEIZE", 
              "DIX-SEPT", "DIX-HUIT", "DIX-NEUF"]
    dizaines = ["", "DIX", "VINGT", "TRENTE", "QUARANTE", "CINQUANTE", 
                "SOIXANTE", "SOIXANTE-DIX", "QUATRE-VINGT", "QUATRE-VINGT-DIX"]
    
    if n < 20:
        return unites[n]
    elif n < 100:
        d = n // 10
        u = n % 10
        if d == 7:
            return "SOIXANTE-" + unites[10 + u] if u else "SOIXANTE"
        elif d == 9:
            return "QUATRE-VINGT-" + unites[10 + u] if u else "QUATRE-VINGT"
        elif u == 0:
            return dizaines[d]
        elif u == 1 and d != 8:
            return dizaines[d] + "-ET-UN"
        else:
            return dizaines[d] + "-" + unites[u]
    elif n < 1000:
        c = n // 100
        r = n % 100
        if c == 1:
            return "CENT" + ((" " + nombre_en_lettres(r)) if r else "")
        else:
            return unites[c] + " CENT" + ((" " + nombre_en_lettres(r)) if r else "")
    else:
        return "MILLE" + ((" " + nombre_en_lettres(n % 1000)) if n % 1000 else "")

def create_devis(client_name, services, tva=18):
    """Crée un devis en HTML puis PDF"""
    
    devis_number = f"DEV-{datetime.datetime.now().strftime('%Y%m')}-{random.randint(1000, 9999)}"
    total_ht = sum(s['price'] for s in services)
    tva_amount = total_ht * tva / 100
    total_ttc = total_ht + tva_amount
    
    # Générer les lignes du tableau
    services_rows = ""
    for s in services:
        services_rows += f"""
        <tr>
            <td>{s['name']}</td>
            <td style="text-align:center">1</td>
            <td style="text-align:right">{s['price']:,}</td>
            <td style="text-align:right">{s['price']:,}</td>
        </tr>
        """
    
    # Générer le HTML complet
    html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Devis {client_name}</title>
    <style>
        @page {{
            size: A4;
            margin: 2cm;
        }}
        body {{
            font-family: 'Segoe UI', Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: white;
        }}
        .devis {{
            max-width: 100%;
            margin: 0 auto;
        }}
        .header {{
            text-align: center;
            border-bottom: 2px solid #1E3A5F;
            padding-bottom: 20px;
            margin-bottom: 20px;
        }}
        .header h1 {{
            color: #1E3A5F;
            margin: 0;
            font-size: 28px;
        }}
        .header p {{
            color: #666;
            margin: 5px 0 0;
        }}
        .info {{
            margin: 20px 0;
            padding: 15px;
            background: #F5F7FA;
            border-radius: 10px;
        }}
        .info table {{
            width: 100%;
        }}
        .info td {{
            padding: 5px;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }}
        th, td {{
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }}
        th {{
            background: #1E3A5F;
            color: white;
        }}
        .total {{
            text-align: right;
            margin-top: 20px;
            padding-top: 10px;
            border-top: 2px solid #1E3A5F;
        }}
        .total h2 {{
            color: #1E3A5F;
            margin: 0;
        }}
        .footer {{
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            font-size: 12px;
            color: #666;
        }}
        .conditions {{
            margin-top: 30px;
            padding: 15px;
            background: #F9F9F9;
            border-radius: 8px;
            font-size: 11px;
        }}
        .montant-lettres {{
            margin-top: 20px;
            padding: 10px;
            background: #F0F4F8;
            border-left: 3px solid #1E3A5F;
            font-style: italic;
        }}
    </style>
</head>
<body>
    <div class="devis">
        <div class="header">
            <h1>🌊 AFRICA GOLDEN DIGITAL</h1>
            <p>Devis Professionnel</p>
        </div>
        
        <div class="info">
            <table>
                <tr><td width="50%"><strong>Devis N°</strong></td><td>{devis_number}</td>
                <td><strong>Date</strong></td><td>{datetime.datetime.now().strftime('%d/%m/%Y')}</td></tr>
                <tr><td><strong>Client</strong></td><td>{client_name}</td>
                <td><strong>Validité</strong></td><td>30 jours</td></tr>
            </table>
        </div>
        
        <h3>📋 Détail des prestations</h3>
        <table>
            <tr>
                <th>Service</th>
                <th style="width:80px; text-align:center">Qté</th>
                <th style="width:120px; text-align:right">Prix unitaire (FCFA)</th>
                <th style="width:120px; text-align:right">Montant (FCFA)</th>
            </tr>
            {services_rows}
        </table>
        
        <div class="total">
            <h2>SOUS-TOTAL HT : {total_ht:,} FCFA</h2>
            <p>TVA ({tva}%) : {tva_amount:,.0f} FCFA</p>
            <h2 style="color: #C9A87C;">TOTAL TTC : {total_ttc:,.0f} FCFA</h2>
        </div>
        
        <div class="montant-lettres">
            <strong>Arrêté le présent devis à la somme de :</strong><br>
            {nombre_en_lettres(int(total_ttc))} FRANCS CFA
        </div>
        
        <div class="conditions">
            <strong>📌 Conditions :</strong><br>
            - Devis valable 30 jours<br>
            - Paiement à réception<br>
            - Commencez dès validation<br>
            - En cas de retard, pénalité de 10%
        </div>
        
        <div class="footer">
            <p>📱 WhatsApp : +2290149308718 | 📧 contact@africagoldendigital.com</p>
            <p>🌊 KORA - Assistante IA | Merci de votre confiance</p>
        </div>
    </div>
</body>
</html>"""
    
    # Sauvegarder le HTML
    html_filename = f"C:\\Users\\DELL\\Desktop\\devis_{client_name.replace(' ', '_')}_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.html"
    with open(html_filename, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    # Convertir en PDF
    pdf_filename = html_filename.replace('.html', '.pdf')
    HTML(string=html_content).write_pdf(pdf_filename)
    
    print(f"\n✅ DEVIS CRÉÉ AVEC SUCCÈS !")
    print(f"="*50)
    print(f"   📄 PDF : {pdf_filename}")
    print(f"   📊 Total HT : {total_ht:,} FCFA")
    print(f"   📊 Total TTC : {total_ttc:,.0f} FCFA")
    print(f"   🏷️  Devis N° : {devis_number}")
    print(f"   👤 Client : {client_name}")
    print(f"="*50)
    
    return pdf_filename

def main():
    if len(sys.argv) < 4:
        print("\n" + "="*60)
        print("🏢 GÉNÉRATEUR DE DEVIS (HTML → PDF)")
        print("="*60)
        print("\nUtilisation:")
        print("  python devis_complet.py <client> <service1> <prix1> [service2] [prix2] ...")
        print("\nExemple:")
        print("  python devis_complet.py 'Jean Dupont' 'Création site' 250000 'Formation' 100000")
        print("="*60)
        sys.exit(1)
    
    client = sys.argv[1]
    services = []
    
    i = 2
    while i < len(sys.argv):
        if i+1 < len(sys.argv):
            try:
                price = int(sys.argv[i+1])
                services.append({"name": sys.argv[i], "price": price})
                i += 2
            except ValueError:
                i += 1
        else:
            i += 1
    
    if not services:
        print("❌ Aucun service valide trouvé")
        sys.exit(1)
    
    print("\n" + "="*60)
    print("🏢 AFRICA GOLDEN DIGITAL - GÉNÉRATION DE DEVIS")
    print("="*60)
    print(f"👤 Client : {client}")
    print(f"📦 Services :")
    for s in services:
        print(f"   - {s['name']} : {s['price']:,} FCFA")
    print("="*60)
    
    create_devis(client, services)

if __name__ == "__main__":
    main()