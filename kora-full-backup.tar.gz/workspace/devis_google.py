#!/usr/bin/env python3
"""
Devis avec Google Docs API
Créé pour KORA
"""

import datetime
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
import os

def create_devis_google(client_name, services, total):
    """Crée un devis via Google Docs"""
    
    TEMPLATE_ID = "ton_template_id"  # ID du document template
    
    # Copier le template
    creds = get_credentials()
    service = build('docs', 'v1', credentials=creds)
    
    # Nouveau document
    new_doc = service.documents().copy(
        documentId=TEMPLATE_ID,
        body={'title': f"Devis {client_name}"}
    ).execute()
    
    doc_id = new_doc['id']
    
    # Remplacer les variables
    service.documents().batchUpdate(
        documentId=doc_id,
        body={
            'requests': [
                {
                    'replaceAllText': {
                        'containsText': {'text': '{{client_name}}'},
                        'replaceText': client_name
                    }
                },
                {
                    'replaceAllText': {
                        'containsText': {'text': '{{date}}'},
                        'replaceText': datetime.datetime.now().strftime('%d/%m/%Y')
                    }
                },
                {
                    'replaceAllText': {
                        'containsText': {'text': '{{total}}'},
                        'replaceText': f"{total:,} FCFA"
                    }
                }
            ]
        }
    ).execute()
    
    # Exporter en PDF
    pdf_data = service.documents().export(documentId=doc_id, mimeType='application/pdf').execute()
    
    # Sauvegarder
    pdf_filename = f"C:\\Users\\DELL\\Desktop\\DEVIS_{client_name}_{datetime.datetime.now().strftime('%Y%m%d')}.pdf"
    with open(pdf_filename, 'wb') as f:
        f.write(pdf_data)
    
    print(f"✅ Devis créé : {pdf_filename}")
    return pdf_filename

def get_credentials():
    """Obtient les credentials Google"""
    creds = None
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json')
    
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            from google_auth_oauthlib.flow import InstalledAppFlow
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', ['https://www.googleapis.com/auth/documents']
            )
            creds = flow.run_local_server(port=0)
        
        with open('token.json', 'w') as token:
            token.write(creds.to_json())
    
    return creds

if __name__ == "__main__":
    create_devis_google("Jean Dupont", [], 350000)