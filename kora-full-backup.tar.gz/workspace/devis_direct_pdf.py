#!/usr/bin/env python3
"""
Génère un devis PDF directement (sans Markdown)
Créé pour KORA - Africa Golden Digital
"""

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.lib.enums import TA_CENTER, TA_RIGHT
import datetime
import random
import sys

def create_devis_pdf_direct(client_name, services, tva=18):
    """Crée un devis PDF directement"""
    
    devis_number = f"DEV-{datetime.datetime.now().strftime('%Y%m')}-{random.randint(1000, 9999)}"
    total_ht = sum(s['price'] for s in services)
    tva_amount = total_ht * tva / 100
    total_ttc = total_ht + tva_amount
    
    filename = f"C:\\Users\\DELL\\Desktop\\DEVIS_{client_name.replace(' ', '_')}_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.pdf"
    
    doc = SimpleDocTemplate(filename, pagesize=A4, topMargin=2*cm, bottomMargin=2*cm)
    story = []
    styles = getSampleStyleSheet()
    
    # Style titre
    title_style = ParagraphStyle('TitleStyle', parent=styles['Normal'],
                                   fontSize=24, textColor=colors.HexColor('#1E3A5F'),
                                   alignment=TA_CENTER, spaceAfter=10)
    
    # En-tête
    story.append(Paragraph("🌊 AFRICA GOLDEN DIGITAL", title_style))
    story.append(Paragraph("DEVIS PROFESSIONNEL", ParagraphStyle('SubStyle', parent=styles['Normal'],
                                   fontSize=14, textColor=colors.HexColor('#666666'),
                                   alignment=TA_CENTER, spaceAfter=20)))
    
    # Informations
    info_data = [
        ["Devis N°", devis_number],
        ["Date", datetime.datetime.now().strftime('%d/%m/%Y')],
        ["Client", client_name],
        ["Validité", "30 jours"]
    ]
    
    info_table = Table(info_data, colWidths=[4*cm, 8*cm])
    info_table.setStyle(TableStyle([
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('ALIGN', (0, 0), (0, -1), 'RIGHT'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(info_table)
    story.append(Spacer(1, 20))
    
    # Tableau des services
    table_data = [['Service', 'Qté', 'Prix unitaire (FCFA)', 'Montant (FCFA)']]
    for s in services:
        table_data.append([s['name'], '1', f"{s['price']:,}", f"{s['price']:,}"])
    
    service_table = Table(table_data, colWidths=[8*cm, 2*cm, 3*cm, 3*cm])
    service_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1E3A5F')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#CCCCCC')),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
    ]))
    story.append(service_table)
    story.append(Spacer(1, 20))
    
    # Totaux
    total_data = [
        ["Total HT", f"{total_ht:,} FCFA"],
        [f"TVA ({tva}%)", f"{tva_amount:,.0f} FCFA"],
        ["TOTAL TTC", f"{total_ttc:,.0f} FCFA"]
    ]
    
    total_table = Table(total_data, colWidths=[10*cm, 6*cm])
    total_table.setStyle(TableStyle([
        ('ALIGN', (0, 0), (0, -1), 'RIGHT'),
        ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
        ('FONTNAME', (0, -1), (1, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, -1), (1, -1), 12),
        ('TEXTCOLOR', (0, -1), (1, -1), colors.HexColor('#1E3A5F')),
        ('TOPPADDING', (0, 0), (-1, -1), 5),
    ]))
    story.append(total_table)
    story.append(Spacer(1, 30))
    
    # Pied de page
    footer_style = ParagraphStyle('FooterStyle', parent=styles['Normal'],
                                   fontSize=9, textColor=colors.grey, alignment=TA_CENTER)
    story.append(Paragraph("Merci de votre confiance. Paiement à réception sous 30 jours.", footer_style))
    story.append(Paragraph("📱 WhatsApp: +2290149308718 | 📧 contact@africagoldendigital.com", footer_style))
    story.append(Paragraph("🌊 KORA - Assistante IA", footer_style))
    
    doc.build(story)
    print(f"✅ DEVIS PDF CRÉÉ : {filename}")
    return filename

def main():
    if len(sys.argv) < 4:
        print("\n" + "="*60)
        print("🏢 GÉNÉRATEUR DE DEVIS PDF")
        print("="*60)
        print("\nUtilisation:")
        print("  python devis_direct_pdf.py <client> <service1> <prix1> [service2] [prix2] ...")
        print("\nExemple:")
        print("  python devis_direct_pdf.py 'Jean Dupont' 'Création site' 250000 'Formation' 100000")
        print("="*60)
        sys.exit(1)
    
    client = sys.argv[1]
    services = []
    
    i = 2
    while i < len(sys.argv):
        if i+1 < len(sys.argv):
            try:
                price = int(sys.argv[i+1])
                services.append({"name": sys.argv[i], "price": price})
                i += 2
            except:
                i += 1
        else:
            i += 1
    
    if not services:
        print("❌ Aucun service valide trouvé")
        sys.exit(1)
    
    print("\n" + "="*60)
    print("🏢 AFRICA GOLDEN DIGITAL - DEVIS")
    print("="*60)
    print(f"👤 Client : {client}")
    print(f"📦 Services :")
    for s in services:
        print(f"   - {s['name']} : {s['price']:,} FCFA")
    print("="*60 + "\n")
    
    create_devis_pdf_direct(client, services)

if __name__ == "__main__":
    main()