#!/usr/bin/env python3
"""
Devis ULTRA PROFESSIONNEL - Design luxe
Créé pour KORA - Africa Golden Digital
"""

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm, mm
from reportlab.lib.enums import TA_CENTER, TA_RIGHT, TA_LEFT
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from PIL import Image as PILImage
import datetime
import random
import sys
import os

# Palette de couleurs professionnelles
PALETTES = [
    {
        "name": "Luxe Bleu",
        "primary": "#1E3A5F",
        "secondary": "#2E5A8A",
        "accent": "#C9A87C",
        "light": "#F5F7FA",
        "dark": "#0B2B4A",
        "gradient_start": "#1E3A5F",
        "gradient_end": "#2E5A8A"
    },
    {
        "name": "Luxe Vert",
        "primary": "#1F4A3C",
        "secondary": "#2E6A55",
        "accent": "#D4AF7A",
        "light": "#F4F8F2",
        "dark": "#0F2A20",
        "gradient_start": "#1F4A3C",
        "gradient_end": "#2E6A55"
    },
    {
        "name": "Luxe Bordeaux",
        "primary": "#7A2E2E",
        "secondary": "#9E4A4A",
        "accent": "#E5B85C",
        "light": "#FEF5F5",
        "dark": "#4A1A1A",
        "gradient_start": "#7A2E2E",
        "gradient_end": "#9E4A4A"
    },
    {
        "name": "Luxe Violet",
        "primary": "#4A2C5F",
        "secondary": "#6A4C7F",
        "accent": "#E5B85C",
        "light": "#F0E8F8",
        "dark": "#2A1A3F",
        "gradient_start": "#4A2C5F",
        "gradient_end": "#6A4C7F"
    }
]

def get_palette():
    return random.choice(PALETTES)

def create_watermark(canvas, doc, palette):
    """Ajoute un filigrane élégant"""
    canvas.saveState()
    canvas.setFillColor(colors.HexColor(palette["light"]))
    canvas.setFont('Helvetica', 60)
    canvas.rotate(45)
    canvas.drawString(300, -100, "AFRICA GOLDEN")
    canvas.drawString(350, -50, "DIGITAL")
    canvas.restoreState()

def create_devis_ultra_pro(client_name, services, tva=18):
    """Crée un devis ultra professionnel"""
    
    palette = get_palette()
    devis_number = f"DEV-{datetime.datetime.now().strftime('%Y%m')}-{random.randint(1000, 9999)}"
    total_ht = sum(s['price'] for s in services)
    tva_amount = total_ht * tva / 100
    total_ttc = total_ht + tva_amount
    
    filename = f"C:\\Users\\DELL\\Desktop\\DEVIS_LUXE_{client_name.replace(' ', '_')}_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.pdf"
    
    doc = SimpleDocTemplate(filename, pagesize=A4, topMargin=1.5*cm, bottomMargin=1.5*cm,
                            leftMargin=1.5*cm, rightMargin=1.5*cm)
    story = []
    styles = getSampleStyleSheet()
    
    # Styles personnalisés
    title_style = ParagraphStyle('TitleStyle', parent=styles['Normal'],
                                   fontSize=28, textColor=colors.HexColor(palette["primary"]),
                                   alignment=TA_CENTER, spaceAfter=5, fontName='Helvetica-Bold')
    
    subtitle_style = ParagraphStyle('SubtitleStyle', parent=styles['Normal'],
                                   fontSize=12, textColor=colors.HexColor(palette["accent"]),
                                   alignment=TA_CENTER, spaceAfter=20, fontName='Helvetica')
    
    section_style = ParagraphStyle('SectionStyle', parent=styles['Normal'],
                                   fontSize=14, textColor=colors.HexColor(palette["primary"]),
                                   alignment=TA_LEFT, spaceAfter=10, spaceBefore=20,
                                   fontName='Helvetica-Bold')
    
    # En-tête avec dégradé
    story.append(Paragraph("🌊 AFRICA GOLDEN DIGITAL", title_style))
    story.append(Paragraph("DEVIS PROFESSIONNEL", subtitle_style))
    
    # Ligne décorative
    story.append(Spacer(1, 5))
    
    # Informations
    info_data = [
        ["", ""],
        ["<font color='#666666' size='10'>DEVIS N°</font>", f"<font color='{palette['primary']}' size='11'><b>{devis_number}</b></font>"],
        ["<font color='#666666' size='10'>DATE</font>", f"<font color='{palette['primary']}' size='11'><b>{datetime.datetime.now().strftime('%d/%m/%Y')}</b></font>"],
        ["<font color='#666666' size='10'>CLIENT</font>", f"<font color='{palette['primary']}' size='11'><b>{client_name}</b></font>"],
        ["<font color='#666666' size='10'>VALIDITÉ</font>", "<font color='#666666' size='10'>30 jours</font>"],
        ["", ""],
    ]
    
    info_table = Table(info_data, colWidths=[4*cm, 8*cm])
    info_table.setStyle(TableStyle([
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 0), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
        ('BACKGROUND', (0, 1), (1, -2), colors.HexColor(palette["light"])),
        ('BOX', (0, 1), (1, -2), 0.5, colors.HexColor(palette["secondary"])),
    ]))
    story.append(info_table)
    story.append(Spacer(1, 20))
    
    # Titre section
    story.append(Paragraph("📋 DÉTAIL DES PRESTATIONS", section_style))
    
    # Tableau des services avec design luxe
    table_data = [['SERVICE', 'QTÉ', 'P.U. (FCFA)', 'MONTANT (FCFA)']]
    for s in services:
        table_data.append([
            f"<font face='Helvetica' size='10'>{s['name']}</font>",
            "<font face='Helvetica' size='10'>1</font>",
            f"<font face='Helvetica' size='10'>{s['price']:,}</font>",
            f"<font face='Helvetica' size='10'><b>{s['price']:,}</b></font>"
        ])
    
    service_table = Table(table_data, colWidths=[8*cm, 2*cm, 3*cm, 3*cm])
    service_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor(palette["primary"])),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 11),
        ('FONTSIZE', (0, 1), (-1, -1), 10),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor(palette["secondary"])),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
        ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor(palette["light"])),
        ('BACKGROUND', (0, 2), (-1, -2), colors.white),
    ]))
    story.append(service_table)
    story.append(Spacer(1, 20))
    
    # Totaux avec style
    total_data = [
        ["", f"<font size='10'>Total HT</font>", f"<font size='10'><b>{total_ht:,} FCFA</b></font>"],
        ["", f"<font size='10'>TVA ({tva}%)</font>", f"<font size='10'>{tva_amount:,.0f} FCFA</font>"],
        ["", "<font size='14'><b>TOTAL TTC</b></font>", f"<font size='14' color='{palette['accent']}'><b>{total_ttc:,.0f} FCFA</b></font>"],
    ]
    
    total_table = Table(total_data, colWidths=[10*cm, 4*cm, 4*cm])
    total_table.setStyle(TableStyle([
        ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
        ('ALIGN', (2, 0), (2, -1), 'RIGHT'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
        ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor(palette["light"])),
    ]))
    story.append(total_table)
    story.append(Spacer(1, 30))
    
    # Conditions
    story.append(Paragraph("📌 CONDITIONS", section_style))
    conditions = [
        "• Devis valable 30 jours",
        "• Paiement à réception",
        "• Commencez dès validation",
        "• En cas de retard, pénalité de 10%"
    ]
    for cond in conditions:
        story.append(Paragraph(f"<font size='9' color='#666666'>{cond}</font>", styles['Normal']))
    
    story.append(Spacer(1, 30))
    
    # Pied de page
    story.append(Paragraph("<hr color='#C9A87C' width='100%'/>", styles['Normal']))
    story.append(Spacer(1, 5))
    
    footer_style = ParagraphStyle('FooterStyle', parent=styles['Normal'],
                                   fontSize=8, textColor=colors.grey, alignment=TA_CENTER)
    story.append(Paragraph("📱 WhatsApp: +2290149308718 | 📧 contact@africagoldendigital.com", footer_style))
    story.append(Paragraph("🌊 KORA - Assistante IA | Merci de votre confiance", footer_style))
    
    # Génération avec filigrane
    doc.build(story, onFirstPage=lambda c, d: create_watermark(c, d, palette),
              onLaterPages=lambda c, d: create_watermark(c, d, palette))
    
    print(f"\n✨ DEVIS ULTRA PRO CRÉÉ !")
    print(f"="*50)
    print(f"📄 PDF : {filename}")
    print(f"🎨 Palette : {palette['name']}")
    print(f"💰 Total : {total_ttc:,.0f} FCFA")
    print(f"🏷️ Devis N° : {devis_number}")
    print(f"="*50)
    return filename

def main():
    if len(sys.argv) < 4:
        print("\n" + "="*60)
        print("✨ GÉNÉRATEUR DE DEVIS ULTRA PROFESSIONNEL")
        print("="*60)
        print("\nUtilisation:")
        print("  python devis_ultra_pro.py <client> <service1> <prix1> [service2] [prix2] ...")
        print("\nExemple:")
        print("  python devis_ultra_pro.py 'Jean Dupont' 'Création site' 250000 'Formation' 100000")
        print("\nPalettes disponibles : Luxe Bleu, Vert, Bordeaux, Violet (aléatoire)")
        print("="*60)
        sys.exit(1)
    
    client = sys.argv[1]
    services = []
    
    i = 2
    while i < len(sys.argv):
        if i+1 < len(sys.argv):
            try:
                price = int(sys.argv[i+1])
                services.append({"name": sys.argv[i], "price": price})
                i += 2
            except:
                i += 1
        else:
            i += 1
    
    if not services:
        print("❌ Aucun service valide trouvé")
        sys.exit(1)
    
    print("\n" + "="*60)
    print("✨ AFRICA GOLDEN DIGITAL - DEVIS ULTRA PRO")
    print("="*60)
    print(f"👤 Client : {client}")
    print(f"📦 Services :")
    for s in services:
        print(f"   - {s['name']} : {s['price']:,} FCFA")
    print("="*60 + "\n")
    
    create_devis_ultra_pro(client, services)

if __name__ == "__main__":
    main()