import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side, GradientFill
from openpyxl.chart import BarChart, Reference
from openpyxl.utils import get_column_letter
import random
import datetime

def random_color():
    colors = [
        "FF6B6B", "4ECDC4", "45B7D1", "96CEB4", "FFEAA7", "DDA0DD", 
        "F7B05B", "6C5B7B", "F08A5D", "B83B5E", "2C7DA0", "61C0BF",
        "FF9F1C", "9C89B8", "F25F5C", "E8A87C", "C38D9E", "41B3A2"
    ]
    return random.choice(colors)

wb = openpyxl.Workbook()
ws = wb.active
ws.title = f"KORA_{datetime.datetime.now().strftime('%d%m')}"

# Titre avec dégradé
title_fill = GradientFill(stop=("FF6B6B", "4ECDC4"))
ws.merge_cells('A1:G1')
ws['A1'] = f"📊 RAPPORT KORA - {datetime.datetime.now().strftime('%d/%m/%Y')}"
ws['A1'].font = Font(bold=True, size=18, color="FFFFFF")
ws['A1'].fill = title_fill
ws['A1'].alignment = Alignment(horizontal='center')

# En-têtes avec couleurs aléatoires
headers = ['Client', 'Service', 'Montant (FCFA)', 'Statut', 'Date', 'Score', 'Relance']
for col, header in enumerate(headers, 1):
    cell = ws.cell(row=2, column=col, value=header)
    cell.font = Font(bold=True, color="FFFFFF", size=11)
    cell.fill = PatternFill(start_color=random_color(), end_color=random_color(), fill_type="solid")
    cell.alignment = Alignment(horizontal='center')
    cell.border = Border(left=Side(style='thin'), right=Side(style='thin'),
                         top=Side(style='thin'), bottom=Side(style='thin'))

# Données
data = [
    ['Jean Dupont', 'Automatisation', 150000, 'Payé', '01/03', 95, 'Non'],
    ['Paul Martin', 'Formation IA', 200000, 'En attente', '05/03', 70, 'Oui'],
    ['Marie Durand', 'Pack Entreprise', 500000, 'Validé', '10/03', 100, 'Non'],
    ['Sophie Laurent', 'Conseil', 75000, 'En cours', '12/03', 80, 'Non'],
    ['Lucas Bernard', 'Formation', 100000, 'Payé', '15/03', 90, 'Non'],
    ['Emma Petit', 'Automatisation', 180000, 'Validé', '18/03', 88, 'Non'],
    ['Thomas Robert', 'Pack Premium', 350000, 'En attente', '20/03', 75, 'Oui'],
]

status_colors = {
    'Payé': 'C6EFCE', 'En attente': 'FFEB9C', 'Validé': 'C6EFCE', 'En cours': 'FFD966'
}

for i, row in enumerate(data, 3):
    for j, value in enumerate(row, 1):
        cell = ws.cell(row=i, column=j, value=value)
        cell.border = Border(left=Side(style='thin'), right=Side(style='thin'),
                             top=Side(style='thin'), bottom=Side(style='thin'))
        if j == 4:  # Statut
            cell.fill = PatternFill(start_color=status_colors.get(value, 'FFFFFF'),
                                   end_color=status_colors.get(value, 'FFFFFF'),
                                   fill_type="solid")

# Graphique
chart = BarChart()
chart.title = "📈 Montants par client"
chart.style = 10
chart.width = 10
chart.height = 6
data_ref = Reference(ws, min_col=3, min_row=2, max_row=len(data)+1, max_col=3)
cats_ref = Reference(ws, min_col=1, min_row=3, max_row=len(data)+1)
chart.add_data(data_ref, titles_from_data=True)
chart.set_categories(cats_ref)
ws.add_chart(chart, "I2")

# Ajuster largeurs
for col in range(1, 8):
    ws.column_dimensions[get_column_letter(col)].width = 18

filename = f"C:\\Users\\DELL\\Desktop\\KORA_Excel_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
wb.save(filename)
print(f"✅ Excel pro créé : {filename}")