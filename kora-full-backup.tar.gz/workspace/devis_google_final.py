#!/usr/bin/env python3
"""
Générateur de devis avec Google Docs
Créé pour KORA - Africa Golden Digital
"""

import datetime
import os
import pickle
import webbrowser
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents',
          'https://www.googleapis.com/auth/drive.file']

def get_credentials():
    creds = None
    token_path = 'C:\\Users\\DELL\\.openclaw\\workspace\\token.pickle'
    creds_path = 'C:\\Users\\DELL\\.openclaw\\workspace\\credentials.json'
    
    if os.path.exists(token_path):
        with open(token_path, 'rb') as token:
            creds = pickle.load(token)
    
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(creds_path, SCOPES)
            # Utilise un port fixe et ouvre le navigateur
            creds = flow.run_local_server(port=8080, open_browser=True)
        
        with open(token_path, 'wb') as token:
            pickle.dump(creds, token)
    
    return creds

def create_devis_google(client_name, services, tva=18):
    
    total_ht = sum(s['price'] for s in services)
    tva_amount = total_ht * tva / 100
    total_ttc = total_ht + tva_amount
    devis_number = f"DEV-{datetime.datetime.now().strftime('%Y%m')}-{services[0]['price'] % 1000}"
    
    creds = get_credentials()
    docs_service = build('docs', 'v1', credentials=creds)
    drive_service = build('drive', 'v3', credentials=creds)
    
    # Créer un nouveau document
    doc = docs_service.documents().create(body={'title': f'Devis {client_name}'}).execute()
    doc_id = doc['documentId']
    
    # Contenu du devis
    services_text = ""
    for s in services:
        services_text += f"{s['name']} | 1 | {s['price']:,} | {s['price']:,}\n"
    
    content = f"""
🌊 AFRICA GOLDEN DIGITAL

DEVIS N° {devis_number}
Date : {datetime.datetime.now().strftime('%d/%m/%Y')}

Client : {client_name}

DÉTAIL DES PRESTATIONS
Service | Qté | Prix unitaire | Montant
{services_text}

RÉCAPITULATIF
Total HT : {total_ht:,} FCFA
TVA ({tva}%) : {tva_amount:,.0f} FCFA
TOTAL TTC : {total_ttc:,.0f} FCFA

Conditions : Devis valable 30 jours - Paiement à réception

KORA 🌊 - Assistante IA
WhatsApp: +2290149308718
"""
    
    requests = [{
        'insertText': {
            'location': {'index': 1},
            'text': content
        }
    }]
    
    docs_service.documents().batchUpdate(documentId=doc_id, body={'requests': requests}).execute()
    
    # Exporter en PDF
    pdf_data = drive_service.files().export(fileId=doc_id, mimeType='application/pdf').execute()
    
    pdf_filename = f"C:\\Users\\DELL\\Desktop\\DEVIS_{client_name.replace(' ', '_')}_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.pdf"
    with open(pdf_filename, 'wb') as f:
        f.write(pdf_data)
    
    print(f"\n✅ DEVIS CRÉÉ !")
    print(f"="*50)
    print(f"📄 PDF : {pdf_filename}")
    print(f"💰 Total HT : {total_ht:,} FCFA")
    print(f"💰 Total TTC : {total_ttc:,.0f} FCFA")
    print(f"="*50)
    return pdf_filename

def main():
    print("\n" + "="*60)
    print("✨ GÉNÉRATEUR DE DEVIS - GOOGLE DOCS")
    print("="*60)
    
    client = input("👤 Nom du client : ")
    
    services = []
    while True:
        name = input("📦 Service (ou 'fin' pour terminer) : ")
        if name.lower() == 'fin':
            break
        try:
            price = int(input(f"💰 Prix pour {name} (FCFA) : "))
            services.append({"name": name, "price": price})
        except ValueError:
            print("❌ Entrez un nombre valide (ex: 50000)")
    
    if not services:
        print("❌ Aucun service ajouté")
        return
    
    print("\n" + "="*60)
    print("🏢 AFRICA GOLDEN DIGITAL")
    print("="*60)
    print(f"👤 Client : {client}")
    for s in services:
        print(f"   - {s['name']} : {s['price']:,} FCFA")
    print("="*60)
    
    create_devis_google(client, services)

if __name__ == "__main__":
    main()