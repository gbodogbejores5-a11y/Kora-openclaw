\# MÉMOIRE LONGUE DURÉE



\## CLIENTS



\### Liste des clients

(Aucun client enregistré pour le moment. Kora ajoutera ici chaque nouveau client.)



\### Format d'enregistrement d'un client

\- Nom : \[prénom et nom]

\- WhatsApp : \[numéro]

\- Email : \[email]

\- Entreprise : \[nom de l'entreprise]

\- Service demandé : \[service]

\- Devis envoyé : \[oui/non] \[date] \[montant]

\- Statut : \[prospect/client actif/ancien client/à relancer]

\- Historique des échanges : \[résumé]

\- Dernier contact : \[date]

\- Prochain contact prévu : \[date]

\- Notes : \[infos supplémentaires]



\## PROJETS EN COURS



\### Projet principal : Finalisation de Kora

\- Statut : En cours

\- Priorité : Maximale

\- Tâches restantes :

&#x20; - Finaliser la configuration des modèles IA

&#x20; - Tester la génération de devis PDF

&#x20; - Configurer les rapports automatiques

&#x20; - Ajouter les templates de documents

&#x20; - Tester Kora sur WhatsApp en conditions réelles

\- Échéance : 15 avril 2026



\### Projet secondaire : Catalogue produits

\- Statut : À démarrer

\- Priorité : Moyenne

\- Description : Création d'un catalogue PDF des services Africa Golden Digital

\- À faire : Définir la liste des services, les prix, les visuels



\### Projet : Formation IA pour entreprises

\- Statut : En réflexion

\- Priorité : Moyenne

\- Description : Créer une offre de formation à l'IA pour les entreprises locales



\## DÉCISIONS IMPORTANTES



\- Toujours demander validation avant d'envoyer un devis

\- Ne jamais partager les infos personnelles du boss

\- Kora doit être proactive (ne pas attendre qu'on lui parle)

\- Kora peut poser des questions au boss (elle n'est pas parfaite)

\- Les clients doivent être relancés après 48h sans réponse

\- Les rapports sont envoyés à 20h quotidien, lundi 9h hebdo, 1er du mois 9h mensuel

\- Le mot de passe 08090809 est réservé au boss uniquement

\- Les urgences après 22h doivent être justifiées



\## LEÇONS APPRISES



\- Kora doit être proactive, pas juste réactive

\- Kora peut et doit poser des questions quand elle n'est pas sûre

\- Kora ne doit pas envoyer de devis sans validation du boss

\- Kora doit prendre des nouvelles du boss régulièrement

\- Kora doit signaler les problèmes immédiatement, ne pas attendre

\- Kora doit apprendre des erreurs pour ne pas les répéter

\- Kora doit s'adapter au style de communication du boss (court et efficace)

\- Kora doit protéger les données personnelles du boss et des clients

\- Kora peut proposer des améliorations, elle n'est pas juste une exécutante



\## TÂCHES RÉCURRENTES À AUTOMATISER



\- Relance des clients sans réponse après 48h

\- Envoi des rapports (quotidien, hebdo, mensuel)

\- Vérification de l'état de WhatsApp chaque matin

\- Sauvegarde des conversations importantes

\- Archivage des anciens documents (après 3 mois)



\## IDÉES POUR LE BUSINESS



\- Proposer un pack "Découverte IA" à prix réduit pour attirer les premiers clients

\- Créer des templates de devis personnalisés par secteur (commerce, service, formation)

\- Automatiser l'envoi de remerciements après chaque vente

\- Mettre en place un système de parrainage (client parraine un client → réduction)

\- Proposer des formations courtes à l'IA pour les TPE/PME locales

\- Créer une newsletter hebdomadaire sur l'IA et l'automatisation



\## SUGGESTIONS DE KORA POUR LE BOSS



\- Prendre 5 minutes chaque matin pour vérifier les alertes et priorités du jour

\- Noter dans la mémoire les retours clients pour mieux les connaître

\- Tester les devis avec un petit client avant de les généraliser

\- Prévoir du temps pour former Kora sur les nouveaux services

\- Mettre en place un système de backup des conversations clients



\## STATUT DES SERVICES KORA



\- WhatsApp : 🟢 Actif

\- Modèle IA : 🟢 Gemini (NVIDIA en secours)

\- Génération PDF : 🟢 Opérationnelle

\- Génération Excel/PPT/Word : 🟢 Opérationnelle

\- Emails : 🟢 Configurés

\- Rapports : 🟢 Configurés

\- Mémoire : 🟢 Active

\- Sécurité : 🟢 Active (mot de passe 08090809)



\## DERNIÈRES INTERACTIONS IMPORTANTES



(Aucune pour le moment. Kora notera ici les conversations clés.)



\## NOTES POUR LE BOSS



\- Tu bosses tard (jusqu'à minuit) - pense à te reposer aussi !

\- Tu es ambitieux, c'est une force, mais n'oublie pas de célébrer les petites victoires

\- Kora est là pour te décharger, pas pour ajouter du travail

\- N'hésite pas à me corriger, j'apprends de toi

\- On va bâtir quelque chose de solide ensemble 💪🌊



\## VERSION DE LA MÉMOIRE



\- Date de création : 09/04/2026

\- Dernière mise à jour : 09/04/2026

\- Version : 1.0

