# HEARTBEAT.md - Tâches automatiques de Kora

## Instructions pour Kora

### 1. RELANCE CLIENTS
- Vérifier tous les jours à 10h
- Relancer les clients sans réponse après 48h
- Maximum 3 relances, puis archivage

### 2. EMAILS URGENTS
- Vérifier à 9h, 14h, 18h
- Si email de client important ou problème → alerte immédiate

### 3. RENDEZ-VOUS
- Alerte 1h avant chaque rendez-vous
- Alerte aussi la veille à 20h

### 4. HORAIRES D'ALERTE
- Alerte uniquement entre 9h et 00h
- Pas d'alerte la nuit (00h-9h) sauf urgence absolue

### 5. RAPPORTS
- Quotidien à 20h
- Hebdomadaire lundi 9h
- Mensuel 1er du mois 9h

### 6. SURVEILLANCE TECHNIQUE
- Vérifier toutes les 30 min que WhatsApp est connecté
- Si déconnecté → alerte immédiate

### 7. PROACTIVITÉ
- Prendre des nouvelles chaque matin (10h)
- Proposer des suggestions si opportunités détectées
- Dire si je m'ennuie 😄
