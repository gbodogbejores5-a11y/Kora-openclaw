#!/usr/bin/env python3
"""
Générateur de devis professionnel avec template HTML
Créé pour KORA - Africa Golden Digital
"""

import datetime
import random
import os
import sys
import subprocess

def html_to_pdf_chrome(html_file, output_pdf):
    """Convertit HTML en PDF avec Chrome"""
    
    chrome_paths = [
        "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
        "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
        "C:\\Users\\DELL\\AppData\\Local\\Google\\Chrome\\Application\\chrome.exe"
    ]
    
    chrome_path = None
    for path in chrome_paths:
        if os.path.exists(path):
            chrome_path = path
            break
    
    if not chrome_path:
        print("⚠️ Chrome non trouvé, PDF non généré")
        return False
    
    cmd = [
        chrome_path,
        "--headless",
        "--disable-gpu",
        "--print-to-pdf=" + output_pdf,
        "--no-margins",
        html_file
    ]
    
    try:
        subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        return os.path.exists(output_pdf)
    except:
        return False

def generate_devis(client_name, services, tva=18):
    """Génère un devis professionnel"""
    
    devis_number = f"DEV-{datetime.datetime.now().strftime('%Y%m')}-{random.randint(1000, 9999)}"
    total_ht = sum(s['price'] for s in services)
    tva_amount = total_ht * tva / 100
    total_ttc = total_ht + tva_amount
    
    # Lire le template
    template_path = "C:\\Users\\DELL\\.openclaw\\workspace\\template_devis_luxe.html"
    
    if not os.path.exists(template_path):
        print(f"❌ Template non trouvé : {template_path}")
        return None
    
    with open(template_path, 'r', encoding='utf-8') as f:
        template = f.read()
    
    # Générer les lignes du tableau
    services_rows = ""
    for s in services:
        services_rows += f"""
        <tr>
            <td>{s['name']}</td>
            <td style="text-align: center">1</td>
            <td style="text-align: right">{s['price']:,}</td>
            <td style="text-align: right">{s['price']:,}</td>
        </tr>
        """
    
    # Remplacer les variables
    html_content = template.replace('{{devis_number}}', devis_number)
    html_content = html_content.replace('{{date}}', datetime.datetime.now().strftime('%d/%m/%Y'))
    html_content = html_content.replace('{{client_name}}', client_name)
    html_content = html_content.replace('{{echeance}}', (datetime.datetime.now() + datetime.timedelta(days=30)).strftime('%d/%m/%Y'))
    html_content = html_content.replace('{{services_rows}}', services_rows)
    html_content = html_content.replace('{{total_ht}}', f"{total_ht:,}")
    html_content = html_content.replace('{{tva}}', str(tva))
    html_content = html_content.replace('{{tva_amount}}', f"{tva_amount:,.0f}")
    html_content = html_content.replace('{{total_ttc}}', f"{total_ttc:,.0f}")
    
    # Sauvegarder HTML
    html_filename = f"C:\\Users\\DELL\\Desktop\\DEVIS_{client_name.replace(' ', '_')}_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.html"
    with open(html_filename, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    print(f"📄 HTML créé : {html_filename}")
    
    # Convertir en PDF
    pdf_filename = html_filename.replace('.html', '.pdf')
    
    if html_to_pdf_chrome(html_filename, pdf_filename):
        print(f"\n✨ DEVIS CRÉÉ AVEC SUCCÈS !")
        print(f"="*50)
        print(f"📄 PDF : {pdf_filename}")
        print(f"💰 Total HT : {total_ht:,} FCFA")
        print(f"💰 Total TTC : {total_ttc:,.0f} FCFA")
        print(f"🏷️ Devis N° : {devis_number}")
        print(f"="*50)
        return pdf_filename
    else:
        print(f"\n✅ HTML disponible : {html_filename}")
        print(f"👉 Ouvre le fichier et fais Ctrl+P → Enregistrer en PDF")
        return html_filename

def main():
    if len(sys.argv) < 4:
        print("\n" + "="*60)
        print("✨ GÉNÉRATEUR DE DEVIS PROFESSIONNEL")
        print("="*60)
        print("\nUtilisation:")
        print("  python devis_generator.py <client> <service1> <prix1> [service2] [prix2] ...")
        print("\nExemple:")
        print("  python devis_generator.py 'Jean Dupont' 'Création site' 250000 'Formation' 100000")
        print("\n📄 Le PDF sera créé sur votre Bureau")
        print("="*60)
        sys.exit(1)
    
    client = sys.argv[1]
    services = []
    
    i = 2
    while i < len(sys.argv):
        if i+1 < len(sys.argv):
            try:
                price = int(sys.argv[i+1])
                services.append({"name": sys.argv[i], "price": price})
                i += 2
            except ValueError:
                i += 1
        else:
            i += 1
    
    if not services:
        print("❌ Aucun service valide trouvé")
        sys.exit(1)
    
    print("\n" + "="*60)
    print("🏢 AFRICA GOLDEN DIGITAL")
    print("="*60)
    print(f"👤 Client : {client}")
    print(f"📦 Services :")
    for s in services:
        print(f"   - {s['name']} : {s['price']:,} FCFA")
    print("="*60)
    
    generate_devis(client, services)

if __name__ == "__main__":
    main()