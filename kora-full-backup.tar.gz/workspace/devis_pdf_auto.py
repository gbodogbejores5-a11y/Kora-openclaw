#!/usr/bin/env python3
"""
Génère un devis PDF automatiquement
Créé pour KORA - Africa Golden Digital
"""

import datetime
import random
import subprocess
import os
import sys

def nombre_en_lettres(n):
    """Convertit un nombre en lettres"""
    if n == 0:
        return "ZÉRO"
    
    unites = ["", "UN", "DEUX", "TROIS", "QUATRE", "CINQ", "SIX", "SEPT", "HUIT", "NEUF", 
              "DIX", "ONZE", "DOUZE", "TREIZE", "QUATORZE", "QUINZE", "SEIZE", 
              "DIX-SEPT", "DIX-HUIT", "DIX-NEUF"]
    dizaines = ["", "DIX", "VINGT", "TRENTE", "QUARANTE", "CINQUANTE", 
                "SOIXANTE", "SOIXANTE-DIX", "QUATRE-VINGT", "QUATRE-VINGT-DIX"]
    
    if n < 20:
        return unites[n]
    elif n < 100:
        d = n // 10
        u = n % 10
        if d == 7:
            return "SOIXANTE-" + unites[10 + u] if u else "SOIXANTE"
        elif d == 9:
            return "QUATRE-VINGT-" + unites[10 + u] if u else "QUATRE-VINGT"
        elif u == 0:
            return dizaines[d]
        elif u == 1 and d != 8:
            return dizaines[d] + "-ET-UN"
        else:
            return dizaines[d] + "-" + unites[u]
    elif n < 1000:
        c = n // 100
        r = n % 100
        if c == 1:
            return "CENT" + ((" " + nombre_en_lettres(r)) if r else "")
        else:
            return unites[c] + " CENT" + ((" " + nombre_en_lettres(r)) if r else "")
    else:
        return "MILLE" + ((" " + nombre_en_lettres(n % 1000)) if n % 1000 else "")

def create_devis_pdf(client_name, services, tva=18, remise=0):
    """Crée un devis PDF professionnel"""
    
    devis_number = f"DEV-{datetime.datetime.now().strftime('%Y%m')}-{random.randint(1000, 9999)}"
    
    # Calcul des totaux
    total_ht = sum(s['price'] for s in services)
    
    if remise > 0:
        montant_remise = total_ht * remise / 100
        total_ht -= montant_remise
    
    tva_amount = total_ht * tva / 100
    total_ttc = total_ht + tva_amount
    
    # Générer le tableau des services
    services_table = ""
    for s in services:
        services_table += f"| {s['name']} | 1 | {s['price']:,} | {s['price']:,} |\n"
    
    # Créer le contenu MD
    content = f"""---
title: "Devis {client_name}"
author: "Africa Golden Digital"
date: {datetime.datetime.now().strftime('%d/%m/%Y')}
geometry: margin=2.5cm
fontsize: 12pt
mainfont: Arial
---

# 🌊 AFRICA GOLDEN DIGITAL

## DEVIS PROFESSIONNEL

---

### INFORMATIONS

| | |
|---|---|
| **Devis N°** | {devis_number} |
| **Date** | {datetime.datetime.now().strftime('%d/%m/%Y')} |
| **Client** | {client_name} |
| **Validité** | 30 jours |

---

### DÉTAIL DES PRESTATIONS

| Service | Quantité | Prix unitaire | Montant |
|---------|----------|---------------|---------|
{services_table}

---

### RÉCAPITULATIF

| | Montant (FCFA) |
|---|---|
| **Total HT** | {total_ht:,} |
| **TVA ({tva}%)** | {tva_amount:,} |
| **TOTAL TTC** | **{total_ttc:,}** |

---

### MONTANT EN LETTRES

{nombre_en_lettres(int(total_ttc))} francs CFA

---

### CONDITIONS

- Devis valable 30 jours
- Paiement à réception
- Commencez dès validation
- En cas de retard, pénalité de 10%

---

### NOUS CONTACTER

📱 **WhatsApp:** +2290149308718  
📧 **Email:** contact@africagoldendigital.com  
🌊 **KORA** - Votre assistante IA

---
*Ce devis a été généré automatiquement par KORA.*
"""
    
    # Sauvegarder le fichier MD
    md_filename = f"C:\\Users\\DELL\\Desktop\\devis_{client_name.replace(' ', '_')}_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.md"
    with open(md_filename, 'w', encoding='utf-8') as f:
        f.write(content)
    
    # Convertir en PDF
    pdf_filename = md_filename.replace('.md', '.pdf')
    
    try:
        subprocess.run([
            'pandoc', md_filename,
            '-o', pdf_filename,
            '--pdf-engine=pdflatex',
            '-V', 'geometry:margin=2.5cm',
            '-V', 'fontsize=12pt'
        ], capture_output=True, text=True, check=True)
        
        print(f"✅ DEVIS CRÉÉ AVEC SUCCÈS !")
        print(f"   📄 PDF : {pdf_filename}")
        print(f"   📊 Total : {total_ttc:,} FCFA")
        print(f"   🏷️  Devis N° : {devis_number}")
        return pdf_filename
        
    except subprocess.CalledProcessError as e:
        print(f"❌ Erreur conversion PDF : {e.stderr}")
        print(f"📁 Fichier MD sauvegardé : {md_filename}")
        return None

def main():
    if len(sys.argv) < 3:
        print("\n" + "="*60)
        print("🏢 GÉNÉRATEUR DE DEVIS PDF")
        print("="*60)
        print("\nUtilisation:")
        print("  python devis_pdf_auto.py <client> <service1> <prix1> [service2] [prix2] ...")
        print("\nExemples:")
        print("  python devis_pdf_auto.py 'Jean Dupont' 'Création site' 250000")
        print("  python devis_pdf_auto.py 'Marie' 'Site web' 250000 'Formation' 100000")
        print("="*60)
        sys.exit(1)
    
    client = sys.argv[1]
    services = []
    
    # Parcourir les arguments pour les services
    i = 2
    while i < len(sys.argv):
        if i+1 < len(sys.argv):
            try:
                price = int(sys.argv[i+1])
                services.append({"name": sys.argv[i], "price": price})
                i += 2
            except ValueError:
                i += 1
        else:
            i += 1
    
    if not services:
        print("❌ Aucun service valide trouvé")
        sys.exit(1)
    
    print("\n" + "="*60)
    print("🏢 AFRICA GOLDEN DIGITAL - DEVIS")
    print("="*60)
    print(f"👤 Client : {client}")
    print(f"📦 Services : {len(services)}")
    for s in services:
        print(f"   - {s['name']} : {s['price']:,} FCFA")
    print("="*60 + "\n")
    
    create_devis_pdf(client, services)

if __name__ == "__main__":
    main()