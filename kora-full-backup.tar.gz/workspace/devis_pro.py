#!/usr/bin/env python3
"""
Générateur de devis professionnel avec templates
Créé pour KORA - Africa Golden Digital
"""

import os
import json
import random
import datetime
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
import subprocess

# Configuration
CONFIG_PATH = r"C:\Users\DELL\.openclaw\workspace\config_entreprise.json"
TEMPLATES_FOLDER = r"C:\Users\DELL\.openclaw\workspace\templates"

def load_config():
    with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
        return json.load(f)

def get_random_template():
    templates = [f for f in os.listdir(TEMPLATES_FOLDER) if f.endswith('.docx')]
    if not templates:
        return None
    return os.path.join(TEMPLATES_FOLDER, random.choice(templates))

def create_devis(client_name, services, tva=18):
    """Crée un devis professionnel"""
    
    config = load_config()
    total_ht = sum(s['price'] for s in services)
    tva_amount = total_ht * tva / 100
    total_ttc = total_ht + tva_amount
    devis_number = f"DEV-{datetime.datetime.now().strftime('%Y%m')}-{random.randint(100, 999)}"
    
    template_path = get_random_template()
    
    if template_path:
        doc = Document(template_path)
    else:
        doc = Document()
        doc.add_heading(f"{config['logo']} {config['entreprise']}", 0)
        doc.add_paragraph(config['slogan'])
    
    # Remplacer les variables
    for paragraph in doc.paragraphs:
        text = paragraph.text
        replacements = {
            '{{client}}': client_name,
            '{{date}}': datetime.datetime.now().strftime('%d/%m/%Y'),
            '{{number}}': devis_number,
            '{{total_ht}}': f"{total_ht:,}",
            '{{tva}}': f"{tva_amount:,.0f}",
            '{{total_ttc}}': f"{total_ttc:,.0f}",
            '{{slogan}}': config['slogan'],
            '{{signature}}': config['signature'],
            '{{entreprise}}': config['entreprise']
        }
        for key, value in replacements.items():
            if key in text:
                paragraph.text = text.replace(key, value)
    
    # Sauvegarder
    output_path = f"C:\\Users\\DELL\\Desktop\\DEVIS_{client_name.replace(' ', '_')}_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.docx"
    doc.save(output_path)
    
    # Convertir en PDF
    try:
        from docx2pdf import convert
        convert(output_path)
        pdf_path = output_path.replace('.docx', '.pdf')
        print(f"\n✅ DEVIS CRÉÉ !")
        print(f"="*50)
        print(f"📄 PDF : {pdf_path}")
        print(f"💰 Total : {total_ttc:,.0f} FCFA")
        print(f"="*50)
        return pdf_path
    except:
        print(f"✅ Document créé : {output_path}")
        return output_path

def main():
    print("\n" + "="*60)
    print(f"✨ {load_config()['entreprise']} - GÉNÉRATEUR DE DEVIS")
    print("="*60)
    
    client = input("👤 Nom du client : ")
    
    services = []
    i = 1
    while True:
        name = input(f"📦 Service {i} (ou 'fin' pour terminer) : ")
        if name.lower() == 'fin':
            break
        try:
            price = int(input(f"💰 Prix (FCFA) : "))
            services.append({"name": name, "price": price})
            i += 1
        except ValueError:
            print("❌ Entrez un nombre")
    
    if services:
        create_devis(client, services)

if __name__ == "__main__":
    main()