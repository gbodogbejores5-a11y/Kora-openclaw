from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
from pptx.dml.color import RGBColor
import random
import datetime

def random_color():
    return RGBColor(random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)

# Slide 1 - Titre
slide_layout = prs.slide_layouts[0]
slide = prs.slides.add_slide(slide_layout)
title = slide.shapes.title
subtitle = slide.placeholders[1]
title.text = "🌊 Africa Golden Digital"
title.text_frame.paragraphs[0].font.size = Pt(54)
title.text_frame.paragraphs[0].font.bold = True
title.text_frame.paragraphs[0].font.color.rgb = random_color()
subtitle.text = f"Rapport {datetime.datetime.now().strftime('%d/%m/%Y')}\nPrésenté par KORA - Assistante IA"

# Slide 2 - Chiffres
slide = prs.slides.add_slide(prs.slide_layouts[1])
title = slide.shapes.title
content = slide.placeholders[1]
title.text = "📊 Chiffres Clés"
title.text_frame.paragraphs[0].font.color.rgb = random_color()
content.text = "✅ Nouveaux clients : 7\n✅ Chiffre d'affaires : 1 555 000 FCFA\n✅ Taux de satisfaction : 95%\n✅ Projets en cours : 8\n✅ Clients actifs : 12"

# Slide 3 - Services
slide = prs.slides.add_slide(prs.slide_layouts[1])
title = slide.shapes.title
content = slide.placeholders[1]
title.text = "💼 Services Proposés"
title.text_frame.paragraphs[0].font.color.rgb = random_color()
content.text = "🤖 Automatisation WhatsApp\n🎓 Formation IA\n📊 Tableaux de bord\n📄 Création PDF/Excel/PPT\n📧 Gestion emails\n📱 Support client 24/7"

# Slide 4 - Performances
slide = prs.slides.add_slide(prs.slide_layouts[1])
title = slide.shapes.title
content = slide.placeholders[1]
title.text = "🚀 Performances"
title.text_frame.paragraphs[0].font.color.rgb = random_color()
content.text = "⚡ Réponse clients : < 10 secondes\n📈 Conversion : 75%\n🔄 Relances auto : 100%\n💡 Satisfaction : 95%\n🎯 Objectifs atteints : 90%"

# Slide 5 - Prochaines étapes
slide = prs.slides.add_slide(prs.slide_layouts[1])
title = slide.shapes.title
content = slide.placeholders[1]
title.text = "🎯 Roadmap 2026"
title.text_frame.paragraphs[0].font.color.rgb = random_color()
content.text = "✅ Déploiement serveur 24/7\n✅ Intégration Google Calendar\n✅ Templates automatiques\n✅ Formation clients\n✅ Nouveaux outils IA"

# Slide 6 - Contact
slide = prs.slides.add_slide(prs.slide_layouts[1])
title = slide.shapes.title
content = slide.placeholders[1]
title.text = "📞 Contactez KORA"
title.text_frame.paragraphs[0].font.color.rgb = random_color()
content.text = "🌊 KORA - Assistante IA\n📱 WhatsApp : +2290149308718\n📧 Email : contact@africagoldendigital.com\n💼 Disponible 24h/24"

filename = f"C:\\Users\\DELL\\Desktop\\KORA_PPT_{datetime.datetime.now().strftime('%Y%m%d_%H%M')}.pptx"
prs.save(filename)
print(f"✅ PowerPoint pro créé : {filename}")